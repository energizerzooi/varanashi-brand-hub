# Varanashi Asset Studio

Everything needed to make an asset for Varanashi Organic Farms: the brand pack, the
type roster as font files, the lockups, the farm's photographs, the direction
reference, the design checker, and a complete worked example.

**Start with `SKILL.md`.** It is written to be attached to an assistant as a skill, or
read by a person.

```
SKILL.md                     the method — read first
scripts/lint.js              the design check; run it before showing anyone anything
scripts/                     build and check tools
brand-packs/varanashi/
  brand.json                 colours, type, logo construction, the rules
  assets/                    fonts, lockups, photographs, textures
  reference/                 the output matrix, the move set, the direction boards
  example/                   a finished poster and the run that made it
```

Fonts are self-hosted here on purpose. Two of them — Elite Accents and Zyntra Doodle —
are cleared by the family for public use. ST Nazm is published by Studio Sorted as Nazm;
its source page states no licence terms, so confirm with the studio before commercial
release outside the farm.
