#!/usr/bin/env python3
"""layout-studio copy check: mechanics + a facts ledger, so verified copy is never re-checked.

Usage: python3 copycheck.py copy.json --pack brand.json --ledger facts.json [--clear]

copy.json   {"piece": "solar-post", "slots": {"headline": "...", "body": "..."}}
facts.json  {"facts": [{"id": "solar", "claim": "25kW of solar power from the farm's own panels",
                        "tokens": ["25kW", "solar"], "status": "verified|pending|rejected",
                        "source": "17 Oct notes", "checked": "2026-10-17"}],
             "cleared": {"<sha1 of normalised copy>": "2026-11-04"}}

What it does
1. If this exact copy (normalised) is in `cleared`, it stops: nothing to re-check.
2. Mechanics from the brand pack: banned words, banned characters, required spellings, straight quotes.
3. Claims: any sentence with a number, a superlative or a named thing is a claim. It is covered when
   every risky token in it is carried by a ledger fact. Verified -> silent. Pending -> marked.
   Rejected -> fail. Not in the ledger -> listed once, batched, as a question for the person.
4. With --clear and no fails or new claims, the copy hash is written to `cleared`.
Exit code 1 on any fail, 2 when there are new claims to confirm, 0 when clean.
"""
import sys, json, re, hashlib, argparse, unicodedata, datetime

ap = argparse.ArgumentParser()
ap.add_argument("copy"); ap.add_argument("--pack"); ap.add_argument("--ledger"); ap.add_argument("--clear", action="store_true")
a = ap.parse_args()
copy = json.load(open(a.copy))
pack = json.load(open(a.pack)) if a.pack else {}
ledger = json.load(open(a.ledger)) if a.ledger else {"facts": [], "cleared": {}}
ledger.setdefault("cleared", {})

slots = copy.get("slots", copy)
text = "\n".join(f"{v}" for v in slots.values() if isinstance(v, str))
norm = lambda s: re.sub(r"\s+", " ", unicodedata.normalize("NFKC", s).strip().lower())
h = hashlib.sha1(norm(text).encode()).hexdigest()[:16]
if h in ledger["cleared"]:
    print(f"CLEARED · this exact copy passed on {ledger['cleared'][h]}; no re-check needed."); sys.exit(0)

fails, warns, new, pending = [], [], [], []
mech = pack.get("copy", {})
for w in mech.get("banned_words", []):
    for k, v in slots.items():
        if isinstance(v, str) and re.search(rf"(?<!\w){re.escape(w)}(?!\w)", v, re.I):
            fails.append(f"[{k}] banned word “{w}”")
for lab in mech.get("ai_labels", []):
    for k, v in slots.items():
        if isinstance(v, str) and lab.lower() in v.lower(): fails.append(f"[{k}] AI or production label “{lab.strip()}” in public copy")
for k in ("title", "headline", "display"):
    v = slots.get(k)
    if isinstance(v, str) and v.rstrip().endswith(".") and not v.rstrip().endswith("..."): fails.append(f"[{k}] title ends with a full stop")
for k, v in slots.items():
    if isinstance(v, str) and re.search(r"\b(not|never)\s+\w+[^.]*$|,\s*not\s+\w+|\bnot\s+(just|only)\b", v, re.I):
        warns.append(f"[{k}] reads like a 'this, not that' construction; say the one true thing")
for w, why in mech.get("watch_words", {}).items():
    for k, v in slots.items():
        if isinstance(v, str) and re.search(rf"(?<!\w){re.escape(w)}(?!\w)", v, re.I):
            warns.append(f"[{k}] “{w}”: {why}")
for ch, why in mech.get("banned_chars", {}).items():
    for k, v in slots.items():
        if isinstance(v, str) and ch in v: fails.append(f"[{k}] “{ch}” ({why})")
for wrong, right in mech.get("spellings", {}).items():
    for k, v in slots.items():
        if isinstance(v, str) and re.search(rf"(?<!\w){re.escape(wrong)}(?!\w)", v):
            fails.append(f"[{k}] “{wrong}” should be “{right}”")
for k, v in slots.items():
    if isinstance(v, str) and re.search(r"[\"']", v) and mech.get("curly_quotes", True):
        warns.append(f"[{k}] straight quote or apostrophe; use ’ “ ”")
for k, v in slots.items():
    if isinstance(v, str) and "[FACT NEEDED" in v: pending.append(f"[{k}] placeholder still in copy")

SUPER = r"\b(first|only|oldest|largest|biggest|best|most|every|all|never|always|no\.?\s?1|award\w*|certified|organic|zero|100%)\b"
names_ok = set(w.lower() for w in mech.get("known_names", []))
facts = ledger["facts"]
def tokens_of(sent):
    toks = set(re.findall(r"\d[\d,.]*\s?(?:%|kW|km|ft|g|kg|tons?|acres?|years?|generations?|people)?", sent, re.I))
    toks |= set(m.group(0) for m in re.finditer(SUPER, sent, re.I))
    words = re.findall(r"(?<![.!?]\s)(?<!^)\b[A-Z][a-z]{2,}\b", sent)
    toks |= set(w for w in words if w.lower() not in names_ok)
    return {t.strip().lower() for t in toks if t.strip()}

for k, v in slots.items():
    if not isinstance(v, str): continue
    for f in facts:
        if f["status"] == "rejected" and all(t.lower() in norm(v) for t in f.get("tokens", [])):
            fails.append(f"[{k}] says “{f['claim']}”, which is rejected: {f.get('source','')}")
    for sent in re.split(r"(?<=[.!?])\s+|\n", v):
        risky = tokens_of(sent)
        if not risky: continue
        covered, st = set(), None
        for f in facts:
            ft = {t.lower() for t in f.get("tokens", [])}
            low = norm(sent)
            hit = {r for r in risky if any(r == t or r.replace(" ", "") == t.replace(" ", "") for t in ft)}
            # a fact covers the sentence only if all of its tokens are present (25kW alone is not "25kW solar")
            if hit and all(t in low or t.replace(" ", "") in low.replace(" ", "") for t in ft):
                covered |= hit
                st = f["status"] if st in (None, "verified") else st
                if f["status"] == "rejected": fails.append(f"[{k}] “{sent}” uses rejected fact {f['id']}")
                if f["status"] == "pending": pending.append(f"[{k}] “{sent}” rests on pending fact {f['id']} ({f.get('source','')})")
        rest = risky - covered
        if rest: new.append({"slot": k, "sentence": sent, "unverified": sorted(rest)})

print(f"copy {copy.get('piece','')} · hash {h}")
for x in fails: print("  ✗", x)
for x in warns: print("  !", x)
for x in pending: print("  … PENDING", x)
if new:
    print("  ? NEW CLAIMS (ask once, all together):")
    for n in new: print(f"     [{n['slot']}] “{n['sentence']}” → confirm: {', '.join(n['unverified'])}")
if not (fails or new or pending): print("  ✓ clean: every claim is on the ledger as verified")
if a.clear and not (fails or new) and a.ledger:
    ledger["cleared"][h] = datetime.date.today().isoformat()
    json.dump(ledger, open(a.ledger, "w"), indent=1, ensure_ascii=False); print("  → cleared; identical copy will skip this check next time")
sys.exit(1 if fails else 2 if new else 0)
