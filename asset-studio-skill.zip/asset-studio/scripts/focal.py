#!/usr/bin/env python3
"""Find the focal area of each photo (where shapes, stickers and patterns must never go).
Spectral-residual saliency + local contrast + a soft centre prior → the tightest box holding ~70% of the saliency mass.
Usage: python3 focal.py photos_dir out.json [--sheet preview.jpg]
Output: {"name": {"box": [x0,y0,x1,y1] (0–1 of the source), "size": [w,h]}}. Edit a box by hand if the subject is wrong; the file wins."""
import sys, json, glob, os, numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as nd

def saliency(img):
    g = np.asarray(img.convert("L").resize((128, int(128 * img.height / img.width))), float) / 255
    F = np.fft.fft2(g); A = np.log(np.abs(F) + 1e-6); P = np.angle(F)
    R = A - nd.uniform_filter(A, 3)
    s = np.abs(np.fft.ifft2(np.exp(R + 1j * P))) ** 2
    s = nd.gaussian_filter(s, 3)
    lab = np.asarray(img.convert("RGB").resize(g.shape[::-1]), float) / 255
    mean = nd.gaussian_filter(lab, (14, 14, 0)); con = np.linalg.norm(lab - mean, axis=2)      # colour pops against surroundings
    s = s / s.max() + .8 * nd.gaussian_filter(con, 2) / con.max()
    h, w = s.shape; yy, xx = np.mgrid[0:h, 0:w]
    s *= np.exp(-(((xx / w - .5) / .42) ** 2 + ((yy / h - .5) / .42) ** 2))                 # photographers centre subjects
    return s / s.max()

def box(s, mass=.7):
    h, w = s.shape; m = s ** 2; tot = m.sum()
    cy, cx = nd.center_of_mass(m)
    for r in np.linspace(.08, .7, 63):                    # grow a box around the mass centre until it holds `mass`
        x0, x1 = max(0, cx - r * w), min(w, cx + r * w); y0, y1 = max(0, cy - r * h), min(h, cy + r * h)
        if m[int(y0):int(y1), int(x0):int(x1)].sum() >= mass * tot: break
    return [round(x0 / w, 3), round(y0 / h, 3), round(x1 / w, 3), round(y1 / h, 3)]

if __name__ == "__main__":
    d, out = sys.argv[1], sys.argv[2]
    res = json.load(open(out)) if os.path.exists(out) else {}
    files = sorted(glob.glob(os.path.join(d, "*.jpg")) + glob.glob(os.path.join(d, "*.png")))
    tiles = []
    for f in files:
        n = os.path.splitext(os.path.basename(f))[0]; im = Image.open(f)
        if n not in res or not res[n].get("manual"):
            res[n] = {"box": box(saliency(im)), "size": list(im.size)}
        b = res[n]["box"]; t = im.convert("RGB").resize((300, int(300 * im.height / im.width)))
        dr = ImageDraw.Draw(t); dr.rectangle([b[0] * t.width, b[1] * t.height, b[2] * t.width, b[3] * t.height], outline=(255, 40, 120), width=4)
        dr.text((6, 6), n, fill=(255, 255, 255)); tiles.append(t)
    json.dump(res, open(out, "w"), indent=1); print(json.dumps(res, indent=0)[:1500])
    if "--sheet" in sys.argv:
        H = max(t.height for t in tiles); S = Image.new("RGB", (310 * min(6, len(tiles)), (H + 10) * (-(-len(tiles) // 6))), "white")
        for i, t in enumerate(tiles): S.paste(t, ((i % 6) * 310, (i // 6) * (H + 10)))
        S.save(sys.argv[sys.argv.index("--sheet") + 1])
