#!/usr/bin/env node
/* layout-studio lint: renders an HTML layout and measures it.
   Usage: node lint.js page.html [--pack brand.json] [--out dir] [--overlay]
   The page must have one root element #canvas with data-grid='{"cols":12,"margin":72,"gutter":24,"unit":8}'
   and optional data-safe='{"top":0,"bottom":120}'. Tag elements with data-role:
   display | text | label | number | photo | shape | logo | ignore.  data-bleed on anything meant to break the grid.
   Writes <out>/<name>.png, <name>.squint.png, <name>.overlay.png (with --overlay) and <name>.lint.json. */
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');

const args = process.argv.slice(2);
const file = path.resolve(args[0]);
const opt = (k, d) => { const i = args.indexOf(k); return i > -1 ? args[i + 1] : d; };
const pack = opt('--pack') ? JSON.parse(fs.readFileSync(opt('--pack'), 'utf8')) : null;
const out = path.resolve(opt('--out', path.dirname(file)));
const overlay = args.includes('--overlay');
const name = path.basename(file, '.html');
fs.mkdirSync(out, { recursive: true });

// ---------- colour maths ----------
const lin = c => { c /= 255; return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
const lum = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
const hex2rgb = h => { h = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16)); };
const oklab = ([r, g, b]) => {
  const [R, G, B] = [r, g, b].map(lin);
  const l = Math.cbrt(0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B);
  const m = Math.cbrt(0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B);
  const s = Math.cbrt(0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B);
  return [0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s, 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s, 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s];
};
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 2000, height: 2000 }, deviceScaleFactor: 1 });
  await page.goto('file://' + file);
  await page.evaluate(() => document.fonts.ready);
  await page.waitForFunction(() => !document.querySelector('#canvas[data-busy]'), null, { timeout: 5000 }).catch(() => {});
  await page.waitForTimeout(150);

  const info = await page.evaluate(() => {
    const cv = document.querySelector('#canvas');
    // untagged text is still text: tag any element that carries its own visible text and has no role
    cv.querySelectorAll('*').forEach(n => {
      if (n.closest('[data-role]') || n.closest('svg')) return;
      const own = [...n.childNodes].some(c => c.nodeType === 3 && c.textContent.trim());
      if (own) { const fs = parseFloat(getComputedStyle(n).fontSize); n.setAttribute('data-role', fs >= 60 ? 'display' : 'text'); n.setAttribute('data-auto', ''); }
    });
    const cr = cv.getBoundingClientRect();
    const grid = JSON.parse(cv.dataset.grid || '{"cols":12,"margin":72,"gutter":24,"unit":8}');
    const safe = JSON.parse(cv.dataset.safe || '{}');
    const els = [...cv.querySelectorAll('[data-role]')].filter(e => e.dataset.role !== 'ignore').map((e, i) => {
      const r = e.getBoundingClientRect(), cs = getComputedStyle(e);
      // ink-ish text rects: union of the text's line boxes, not the element box
      let lines = [];
      if (['display', 'text', 'label', 'number'].includes(e.dataset.role)) {
        const rg = document.createRange(); rg.selectNodeContents(e);
        lines = [...rg.getClientRects()].filter(q => q.width > 1 && q.height > 1).map(q => ({ x: q.left - cr.left, y: q.top - cr.top, w: q.width, h: q.height }));
      }
      return {
        i, role: e.dataset.role, id: e.id || e.className || e.tagName, text: (e.innerText || '').slice(0, 60),
        bleed: e.hasAttribute('data-bleed') || e.hasAttribute('data-free'), free: e.hasAttribute('data-free'), skipContrast: e.dataset.contrast || null, el_allow: e.hasAttribute('data-allow-focal'), x: r.left - cr.left, y: r.top - cr.top, w: r.width, h: r.height,
        fontSize: parseFloat(cs.fontSize), family: cs.fontFamily.split(',')[0].replace(/["']/g, '').trim(),
        color: cs.color, align: cs.textAlign, lines,
        inkL: (() => { if (!lines.length || parseFloat(cs.fontSize) < 48) return 0; const c = document.createElement('canvas').getContext('2d');
          c.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`; const t = (e.innerText || '').trim().split('\n')[0]; if (!t) return 0;
          return -c.measureText(t).actualBoundingBoxLeft; })()
      };
    });
    const fams = [...document.fonts].map(f => ({ family: f.family.replace(/["']/g, ''), status: f.status }));
    return { W: cr.width, H: cr.height, grid, safe, els, fams };
  });

  const { W, H, grid, safe, els } = info;
  const shot = async (p, css) => {
    let h; if (css) h = await page.addStyleTag({ content: css });
    const b = await page.locator('#canvas').screenshot({ path: p });
    if (h) await h.evaluate(n => n.remove());
    return b;
  };
  const finalPng = path.join(out, name + '.png');
  await shot(finalPng);
  // ground pass: text and logos hidden, to sample what is behind them
  const groundBuf = await shot(null, `[data-role=display],[data-role=text],[data-role=label],[data-role=number]{color:transparent!important;-webkit-text-stroke:0!important;text-shadow:none!important}
    [data-role=display] *,[data-role=text] *,[data-role=label] *,[data-role=number] *{color:transparent!important;fill:transparent!important}
    [data-role=logo]{visibility:hidden!important}`);

  // decode both screenshots in the browser
  const decode = async (buf, st) => ({ st, a: await page.evaluate(async ([b64, st]) => {
    const im = new Image(); im.src = 'data:image/png;base64,' + b64; await im.decode();
    const c = document.createElement('canvas'); c.width = im.width; c.height = im.height;
    const x = c.getContext('2d'); x.drawImage(im, 0, 0);
    const d = x.getImageData(0, 0, im.width, im.height).data, o = [];
    for (let y = 0; y < im.height; y += st) for (let q = 0; q < im.width; q += st) { const k = (y * im.width + q) * 4; o.push(d[k], d[k + 1], d[k + 2]); }
    return o;
  }, [buf.toString('base64'), st]) });
  const finalBuf = fs.readFileSync(finalPng);
  const G = await decode(groundBuf, 2), F = await decode(finalBuf, 4);
  const px = (A, x, y) => { const st = A.st, w = Math.ceil(W / st), h = Math.ceil(H / st);
    x = Math.max(0, Math.min(w - 1, (x / st) | 0)); y = Math.max(0, Math.min(h - 1, (y / st) | 0)); const k = (y * w + x) * 3; return [A.a[k], A.a[k + 1], A.a[k + 2]]; };
  const checks = []; const add = (id, level, msg, data) => checks.push({ id, level, msg, ...(data ? { data } : {}) });
  const textEls = els.filter(e => ['display', 'text', 'label', 'number'].includes(e.role));

  // 1. fonts actually loaded
  const usedFams = [...new Set(textEls.map(e => e.family))];
  const loaded = new Set(info.fams.filter(f => f.status === 'loaded').map(f => f.family));
  const missing = usedFams.filter(f => !loaded.has(f));
  add('fonts', missing.length ? 'fail' : 'pass', missing.length ? `Fonts not loaded (fallback in use): ${missing.join(', ')}` : `All ${usedFams.length} faces loaded`);
  if (pack && pack.type && pack.type.allowed) {
    const off = usedFams.filter(f => !pack.type.allowed.includes(f));
    if (off.length) add('fonts-brand', 'fail', `Faces outside the brand: ${off.join(', ')}`);
  }

  // 2. contrast on the pixels, per text element, worst 10% of ground samples
  const parseRGB = s => s.match(/[\d.]+/g).slice(0, 3).map(Number);
  textEls.forEach(e => {
    if (e.skipContrast) { add('contrast-manual', 'warn', `"${e.text.slice(0, 20)}" is ${e.skipContrast}: check by eye in the squint image`); return; }
    const fg = parseRGB(e.color), rs = [];
    e.lines.forEach(l => { for (let k = 0; k < 40; k++) { const x = l.x + (k % 8 + 0.5) / 8 * l.w, y = l.y + (Math.floor(k / 8) + 0.5) / 5 * l.h; rs.push(ratio(fg, px(G, x, y))); } });
    if (!rs.length) return; rs.sort((a, b) => a - b);
    const worst = rs[Math.floor(rs.length * 0.1)];
    const large = e.fontSize >= 40 || e.role === 'display' || e.role === 'number';
    const need = large ? 3 : 4.5;
    if (worst < need) add('contrast', 'fail', `"${e.text.slice(0, 30)}" ${worst.toFixed(2)}:1 (needs ${need})`, { el: e.i });
  });
  if (!checks.some(c => c.id === 'contrast')) add('contrast', 'pass', `Every text block clears 4.5:1 (3:1 large) on the pixels`);

  // 3. grid snap (horizontal) and alignment axes
  const { cols, margin, gutter, unit } = grid;
  const colW = (W - 2 * margin - (cols - 1) * gutter) / cols;
  const lines = new Set([0, W]);
  for (let c = 0; c < cols; c++) { const x0 = margin + c * (colW + gutter); lines.add(+x0.toFixed(1)); lines.add(+(x0 + colW).toFixed(1)); }
  lines.add(W / 2);
  const L = [...lines];
  const near = x => L.reduce((b, l) => Math.abs(l - x) < Math.abs(b - x) ? l : b, L[0]);
  const tol = 2.5; const off = [];
  els.filter(e => !e.bleed && e.role !== 'ignore').forEach(e => {
    const isText = e.lines.length > 0;
    // text: measure the ink start of the first line (left-aligned) or centre (centred)
    const left = isText ? Math.min(...e.lines.map(l => l.x)) + (e.inkL || 0) : e.x; // text: the ink, not the box
    const right = isText ? Math.max(...e.lines.map(l => l.x + l.w)) : e.x + e.w;
    if (isText && e.align === 'center') { const c = (left + right) / 2; if (Math.abs(near(c) - c) > tol) off.push(`${e.id} centre at ${c.toFixed(0)}`); return; }
    if (isText && (e.align === 'right' || e.align === 'end')) { if (Math.abs(near(right) - right) > tol) off.push(`${e.id} right edge ${right.toFixed(0)}`); return; }
    if (Math.abs(near(left) - left) > tol && left > 0) off.push(`${e.id} ${isText ? 'ink' : 'edge'} at x=${left.toFixed(0)}, nearest line ${near(left).toFixed(0)}${isText && e.inkL ? ` (side-bearing ${e.inkL.toFixed(0)}px: shift by ${(near(left) - left).toFixed(0)}px)` : ''}`);
    if (!isText && e.role !== 'logo' && right < W && Math.abs(near(right) - right) > tol) off.push(`${e.id} right ${right.toFixed(0)}`);
  });
  add('grid', off.length ? 'fail' : 'pass', off.length ? `${off.length} edge(s) off the grid` : 'Every edge sits on a column line, the centre, or bleeds', off.length ? off : undefined);
  // vertical rhythm for non-text blocks
  const voff = els.filter(e => !e.bleed && !e.lines.length && e.y > 0 && e.role !== 'logo').filter(e => Math.abs(Math.round(e.y / unit) * unit - e.y) > 1.5).map(e => `${e.id} top ${e.y.toFixed(1)}`);
  if (voff.length) add('rhythm', 'warn', `${voff.length} block top(s) not on the ${unit}px unit`, voff);
  const lefts = els.filter(e => !e.bleed && e.lines.length && e.align !== 'center').map(e => Math.round(Math.min(...e.lines.map(l => l.x))));
  const axes = [...new Set(lefts.map(x => Math.round(x / 4)))].length;
  add('axes', axes > 3 ? 'warn' : 'pass', `${axes} left alignment axis/axes for text (aim for 1 to 3)`);

  // 4. safe area and overlaps
  const sb = safe.bottom || 0, st = safe.top || 0, ms = margin;
  textEls.forEach(e => e.lines.forEach(l => {
    if (l.y + l.h > H - sb + 1 && sb) add('safe', 'fail', `"${e.text.slice(0, 24)}" sits in the bottom ${sb}px UI zone`);
    if (st && l.y < st - 1) add('safe', 'fail', `"${e.text.slice(0, 24)}" sits in the top ${st}px UI zone`);
    if (!e.bleed && (l.x + (e.inkL || 0) < ms - 1 || l.x + l.w > W - ms + 1)) add('margin', 'fail', `"${e.text.slice(0, 24)}" crosses the ${ms}px margin`);
  }));
  const ov = [];
  // display type is cap-trimmed, so its element box is the ink band; body text uses its line boxes
  const boxes = (e, o) => (!e.free && !o.free && (e.role === 'display' || e.role === 'number')) ? [{ x: e.x, y: e.y, w: e.w, h: e.h }] : e.lines; // free notes: compare real lines
  for (let a = 0; a < textEls.length; a++) for (let b = a + 1; b < textEls.length; b++) {
    const A = textEls[a], B = textEls[b];
    boxes(A, B).forEach(p => boxes(B, A).forEach(q => { if (p.x < q.x + q.w - 1 && q.x < p.x + p.w - 1 && p.y < q.y + q.h - 1 && q.y < p.y + p.h - 1) ov.push(`${A.id} × ${B.id}`); }));
  }
  if (ov.length) add('overlap', 'fail', `Text overlaps text: ${[...new Set(ov)].join('; ')}`);

  // 4b. titles and eyebrows
  textEls.filter(e => e.role === 'display').forEach(e => { if (/\.\s*$/.test(e.text.trim()) && !/\.\.\.$|…$/.test(e.text.trim())) add('title-stop', 'fail', `Title ends with a full stop: "${e.text.slice(0, 40)}"`); });
  textEls.filter(e => e.role === 'display' && e.lines.length).forEach(d => {
    const top = Math.min(...d.lines.map(l => l.y));
    textEls.filter(o => o !== d && !o.free && (o.role === 'label' || o.role === 'text') && o.fontSize < d.fontSize * 0.3 && o.lines.length).forEach(o => {
      const ob = Math.max(...o.lines.map(l => l.y + l.h));
      if (ob <= top + 2 && top - ob < 140 && Math.abs(o.x - d.x) < 40) add('eyebrow', 'fail', `"${o.text.slice(0, 24)}" sits as an eyebrow over "${d.text.slice(0, 24)}"; cut it or move it`);
    });
  });
  // 5. hierarchy: scale contrast and the number of sizes
  const sizes = [...new Set(textEls.map(e => Math.round(e.fontSize)))].sort((a, b) => b - a);
  const disp = Math.max(...textEls.filter(e => e.role === 'display' || e.role === 'number').map(e => e.fontSize), 0);
  const body = Math.min(...textEls.filter(e => e.role === 'text').map(e => e.fontSize), Infinity);
  const sc = body < Infinity && disp ? disp / body : null;
  const minScale = (pack && pack.targets && pack.targets.scale_min) || 3;
  if (sc !== null) add('scale', sc < minScale ? 'fail' : 'pass', `Display:body ${sc.toFixed(1)}× (min ${minScale}×)`);
  if (sizes.length > 5) add('sizes', 'warn', `${sizes.length} type sizes (${sizes.join(', ')}). Aim for 4 or fewer.`);
  const dispArea = textEls.filter(e => e.role === 'display' || e.role === 'number').reduce((s, e) => s + e.lines.reduce((t, l) => t + l.w * l.h, 0), 0) / (W * H);
  const photoArea = els.filter(e => e.role === 'photo').reduce((s, e) => s + Math.max(0, Math.min(e.x + e.w, W) - Math.max(e.x, 0)) * Math.max(0, Math.min(e.y + e.h, H) - Math.max(e.y, 0)), 0) / (W * H);
  const focal = Math.max(dispArea, photoArea);
  add('focal', focal < 0.12 ? 'warn' : 'pass', `Largest focal mass covers ${(focal * 100).toFixed(0)}% (type ${(dispArea * 100).toFixed(0)}%, photo ${(photoArea * 100).toFixed(0)}%)`);

  // 6. colour activity, outside photos, against the brand tokens
  if (pack && pack.colour && pack.colour.tokens) {
    const toks = Object.entries(pack.colour.tokens).map(([k, v]) => ({ k, lab: oklab(hex2rgb(v)) }));
    const inPhoto = (x, y) => photos.some(e => x >= e.x && x < e.x + e.w && y >= e.y && y < e.y + e.h);
    const cover = {}; let n = 0, offp = 0, step = 4;
    const photos = els.filter(e => e.role === 'photo');
    for (let y = 0; y < H; y += step) for (let x = 0; x < W; x += step) {
      if (inPhoto(x, y)) continue; n++;
      const lab = oklab(px(F, x, y)); let best = null, bd = 9;
      toks.forEach(t => { const d = dist(lab, t.lab); if (d < bd) { bd = d; best = t.k; } });
      if (bd > 0.06) { offp++; continue; }
      cover[best] = (cover[best] || 0) + 1;
    }
    const share = Object.fromEntries(Object.entries(cover).map(([k, v]) => [k, +(v / (W * H / step / step)).toFixed(3)]).sort((a, b) => b[1] - a[1]));
    const roles = pack.colour.roles || {};
    const neutral = new Set([...(roles.ground || []), ...(roles.ink || [])]);
    const active = Object.entries(share).filter(([k, v]) => !neutral.has(k) && v >= 0.03).map(([k]) => k);
    const accentShare = Object.entries(share).filter(([k]) => !neutral.has(k)).reduce((s, [, v]) => s + v, 0);
    const t = pack.targets || {};
    const minActive = t.active_colours_min ?? 1, minAccent = t.accent_share_min ?? 0.08;
    const lvl = (active.length < minActive || accentShare < minAccent) && photoArea < 0.6 ? 'warn' : 'pass';
    add('colour', lvl, `Accent colours in play: ${active.join(', ') || 'none'} · accent share ${(accentShare * 100).toFixed(0)}% of canvas (aim ≥ ${(minAccent * 100).toFixed(0)}% unless the direction is tonal or photo-led)`, share);
    if (n && offp / n > 0.04) add('palette', 'warn', `${(offp / n * 100).toFixed(1)}% of non-photo pixels are off-palette (gradients and anti-aliasing count; check it is intentional)`);
  }

  // 6b. focal areas: no shape, sticker or pattern may cover a photo's subject (pixel test, one element at a time)
  const focals = await page.$$eval('[data-focal]', ns => ns.map(n => n.dataset.focal.split(',').map(Number)));
  if (focals.length) {
    const avoid = await page.$$eval('#canvas [data-avoid]', ns => ns.map((n, i) => { n.setAttribute('data-avoid-i', i); return n.id || n.dataset.avoid || ('shape ' + i); }));
    const hits = [];
    for (let i = 0; i < avoid.length; i++) {
      const b = await shot(null, `[data-avoid-i="${i}"]{visibility:hidden!important}`); const D = await decode(b, 4);
      focals.forEach(([x0, y0, x1, y1], fi) => {
        let n = 0, d = 0;
        for (let y = Math.max(0, y0); y < Math.min(H, y1); y += 4) for (let x = Math.max(0, x0); x < Math.min(W, x1); x += 4) {
          n++; const a = px(F, x, y), c = px(D, x, y); if (Math.abs(a[0] - c[0]) + Math.abs(a[1] - c[1]) + Math.abs(a[2] - c[2]) > 40) d++; }
        if (n && d / n > 0.015) hits.push(`${avoid[i]} covers ${(d / n * 100).toFixed(0)}% of photo focal area ${fi + 1}`);
      });
    }
    add('focal-clear', hits.length ? 'fail' : 'pass', hits.length ? 'Shapes sit on a photo subject' : `${avoid.length} shapes checked: every photo subject is clear`, hits.length ? hits : undefined);
    const tover = [];
    textEls.filter(e => !e.el_allow).forEach(e => e.lines.forEach(l => focals.forEach(([x0, y0, x1, y1]) => { if (l.x < x1 && l.x + l.w > x0 && l.y < y1 && l.y + l.h > y0) tover.push(e.text.slice(0, 24)); })));
    if (tover.length) add('focal-text', 'warn', 'Text sits on a photo subject', [...new Set(tover)]);
  }
  // 7. squint and overlay images for the visual critique
  await page.evaluate(() => { document.querySelector('#canvas').style.filter = 'grayscale(1) blur(10px)'; });
  await page.locator('#canvas').screenshot({ path: path.join(out, name + '.squint.png') });
  await page.evaluate(() => { document.querySelector('#canvas').style.filter = ''; });
  if (overlay) {
    await page.evaluate(({ L, H, unit }) => {
      const cv = document.querySelector('#canvas'); const o = document.createElement('div');
      o.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:9999';
      L.forEach(x => { const d = document.createElement('div'); d.style.cssText = `position:absolute;top:0;bottom:0;left:${x}px;width:1px;background:rgba(255,0,140,.55)`; o.appendChild(d); });
      for (let y = 0; y < H; y += unit * 8) { const d = document.createElement('div'); d.style.cssText = `position:absolute;left:0;right:0;top:${y}px;height:1px;background:rgba(0,160,255,.35)`; o.appendChild(d); }
      if (getComputedStyle(cv).position === 'static') cv.style.position = 'relative'; cv.appendChild(o);
    }, { L, H, unit });
    await page.locator('#canvas').screenshot({ path: path.join(out, name + '.overlay.png') });
  }
  await browser.close();

  const fails = checks.filter(c => c.level === 'fail').length, warns = checks.filter(c => c.level === 'warn').length;
  const res = { file: name, size: [W, H], fails, warns, checks };
  fs.writeFileSync(path.join(out, name + '.lint.json'), JSON.stringify(res, null, 1));
  console.log(`\n${name}: ${fails ? 'FAIL' : 'PASS'} · ${fails} fail · ${warns} warn`);
  checks.forEach(c => { console.log(`  ${c.level === 'pass' ? '✓' : c.level === 'warn' ? '!' : '✗'} ${c.id}: ${c.msg}`); if (c.level !== 'pass' && Array.isArray(c.data)) c.data.forEach(d => console.log(`      · ${d}`)); });
  process.exit(fails ? 1 : 0);
})();
