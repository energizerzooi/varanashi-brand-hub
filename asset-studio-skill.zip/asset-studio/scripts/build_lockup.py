"""Varanashi lockups, v5 — built on the standard X-unit construction.

X = the logotype's x-height, measured on a flat-sided letter ('n'), because the
single-storey a.ss01 overshoots and would make X 0.2% small.
X = 0.5235 em of ST Nazm at wght 800.

  G_h  = 1.0 X   symbol -> wordmark, horizontal      (1.5 X breathable)
  G_v  = 1.5 X   symbol -> wordmark cap top, stacked (2.0 X decorative)
  G_t  = 0.75 X  baseline -> next line's cap/ink top
  clear space = 1.0 X   (1.5 X generous)

Lines stack by BASELINE, not by ink box, which is what the formulae assume.
Symbol height stays at 3.676 X, the ratio in the approved artwork.
"""
import base64, io, json, re, sys
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.misc.transform import Transform

PACK = Path(sys.argv[1]); ASSETS = PACK/"assets"; OUT = ASSETS/"lockups"
OUT.mkdir(parents=True, exist_ok=True)
X = float(sys.argv[2]) if len(sys.argv) > 2 else 64.0     # one X, in px
BREATHE = len(sys.argv) > 3 and sys.argv[3] == "breathe"

WORD, TAG = "Varanashi", "REGENERATIVE AGROFOREST"
KN1, KN2, KN_ONE = "ವಾರಣಾಶಿ", "ಸಾವಯವ ತೋಟ", "ವಾರಣಾಶಿ ಸಾವಯವ ತೋಟ"
KERN = {0:0, 1:-34, 2:-6, 3:-26, 4:0, 5:-8, 6:-8, 7:-10, 8:0}
INK_COL, PAPER = "#2C3D52", "#F4ECDD"
SEED_W, SEED_H = 907, 1559

X_EM     = 0.5235          # ST Nazm 800 x-height on 'n'
WM_FS    = 1/X_EM          # wordmark font-size, in X          = 1.910 X
MARK_H   = 3.676           # symbol height, in X
G_H      = 1.5 if BREATHE else 1.0
G_V      = 1.5
G_T      = 0.54            # solved: at 0.5407 X the three-line block is exactly the symbol's
                           # height, so it sits flush. The approved artwork used ~0.55 X.
                           # 0.75 X is the generic figure and assumes only three elements;
                           # this lockup has four, because Kannada is a second script line.
CLEAR    = 1.0
TAG_CAP  = 0.35            # tagline cap height, in X
KN1_INK  = 1.50            # Kannada lockup, line 1 ink height, in X
SAFETY   = 0.05            # tiny bleed margin so nothing can clip
OPT      = 0.50            # the three-line block is as tall as the symbol, so anything other
                           # than a true centre overhangs. Shorter blocks sit centred inside it.
KASC, KDESC = 0.81, 0.03   # Noto Sans Kannada ink above/below baseline, in em
KNW = {"one400": 11.091, "l1_600": 4.084, "l2_600": 7.341}

SEED_PATHS = re.findall(r'<path d="([^"]+)"', (ASSETS/"varanashi-mark.svg").read_text())
(ASSETS/"seedling_paths.json").write_text(json.dumps(SEED_PATHS, indent=1))

def load(n, **ax):
    f = TTFont(ASSETS/n)
    if ax: instancer.instantiateVariableFont(f, ax, inplace=True)
    return f
def featmap(f, tag):
    o={}
    for fr in f["GSUB"].table.FeatureList.FeatureRecord:
        if fr.FeatureTag==tag:
            for li in fr.Feature.LookupListIndex:
                for st in f["GSUB"].table.LookupList.Lookup[li].SubTable:
                    if type(st).__name__=="SingleSubst": o.update(st.mapping)
    return o
nazm  = load("ST-Nazm-Variable.ttf", wght=800)
quick = load("Quicksand-Variable.ttf", wght=700)
SS01  = featmap(nazm, "ss01")

def run(font, text, kern=None, track=0.0, sub=None):
    cm, hm = font.getBestCmap(), font["hmtx"]; gl, x = [], 0
    for i, ch in enumerate(text):
        g = cm[ord(ch)]
        if sub: g = sub.get(g, g)
        if kern: x += kern.get(i, 0)
        if i: x += track
        gl.append((g, x)); x += hm[g][0]
    return gl, x

def outline(font, gl, fs):
    """paths with the ORIGIN AT THE BASELINE, plus the ink box relative to it."""
    gs, upm = font.getGlyphSet(), font["head"].unitsPerEm
    k = fs/upm; paths=[]; x0=y0=1e9; x1=y1=-1e9
    for g, x in gl:
        pen = SVGPathPen(gs)
        gs[g].draw(TransformPen(pen, Transform(k,0,0,-k, x*k, 0)))
        if pen.getCommands(): paths.append(pen.getCommands())
        bp = BoundsPen(gs); gs[g].draw(bp)
        if bp.bounds:
            a,b,c,d = bp.bounds
            x0=min(x0,(x+a)*k); x1=max(x1,(x+c)*k); y0=min(y0,-d*k); y1=max(y1,-b*k)
    return paths, (x0,y0,x1,y1)

def kn_face(weight):
    """Full pinned face. Subsetting collapses the two-part OO matra in ತೋಟ."""
    kf = TTFont(ASSETS/"NotoSansKannada.ttf")
    instancer.instantiateVariableFont(kf, {"wght": weight, "wdth": 100}, inplace=True)
    for t in ("fpgm","prep","cvt ","gasp","DSIG","VDMX","hdmx","LTSH","PCLT"):
        if t in kf: del kf[t]
    b=io.BytesIO(); kf.save(b); return base64.b64encode(b.getvalue()).decode()
F400, F600 = kn_face(400), kn_face(600)
def defs(*faces):
    css="".join(f'@font-face{{font-family:"{n}";font-weight:400;'
                f'src:url(data:font/ttf;base64,{b}) format("truetype");}}' for n,b in faces)
    return f'<defs><style>{css}</style></defs>'
def seed(h, c, dx, dy):
    return (f'<g transform="translate({dx:.2f},{dy:.2f}) scale({h/SEED_H:.6f})" fill="{c}">'
            + "".join(f'<path d="{d}"/>' for d in SEED_PATHS) + "</g>")

# ---- the three line builders. Each returns ink box RELATIVE TO ITS BASELINE ----
def line_wordmark():
    fs = WM_FS*X
    gl,_ = run(nazm, WORD, kern=KERN, sub=SS01)
    paths,(x0,y0,x1,y1) = outline(nazm, gl, fs)
    return {"kind":"wm","w":x1-x0,"ink_top":y0,"ink_bot":y1,"cap_top":-nazm["OS/2"].sCapHeight/1000*fs,
            "draw": lambda x,base,c: (f'<g fill="{c}" transform="translate({x-x0:.2f},{base:.2f})">'
                                      + "".join(f'<path d="{d}"/>' for d in paths) + "</g>")}
def line_tag(W, text=TAG):
    fs = TAG_CAP*X/(quick["OS/2"].sCapHeight/quick["head"].unitsPerEm)
    upm = quick["head"].unitsPerEm
    _, nat = run(quick, text)
    tr = (W - nat/upm*fs)/(len(text)-1)*upm/fs
    gl,_ = run(quick, text, track=tr)
    paths,(x0,y0,x1,y1) = outline(quick, gl, fs)
    return {"kind":"tag","w":x1-x0,"ink_top":y0,"ink_bot":y1,"cap_top":y0,"track":round(tr),
            "draw": lambda x,base,c: (f'<g fill="{c}" transform="translate({x-x0:.2f},{base:.2f})">'
                                      + "".join(f'<path d="{d}"/>' for d in paths) + "</g>")}
def line_kn(W, key, face, txt):
    fs = W/KNW[key]
    return {"kind":"kn","w":W,"ink_top":-KASC*fs,"ink_bot":KDESC*fs,"cap_top":-KASC*fs,"fs":round(fs,1),
            "draw": lambda x,base,c: (f'<text x="{x:.2f}" y="{base:.2f}" fill="{c}" '
                                      f'font-family="{face}" font-size="{fs:.2f}">{txt}</text>')}

def stack(lines):
    """Place baselines using G_t: baseline -> next line's cap/ink top = 0.75 X."""
    y = 0.0
    for i, l in enumerate(lines):
        if i: y = y + G_T*X - l["cap_top"]
        l["base"] = y
    top = min(l["base"]+l["ink_top"] for l in lines)
    bot = max(l["base"]+l["ink_bot"] for l in lines)
    return top, bot

def wrap(vw, vh, title, faces, body):
    s = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {vw:.1f} {vh:.1f}" '
         f'width="{vw:.1f}" height="{vh:.1f}" role="img" aria-label="{title}"><title>{title}</title>')
    if faces: s += defs(*faces)
    return s + body + "</svg>"

def horizontal(c=INK_COL, kannada=True, tagline=True):
    MH = MARK_H*X
    wm = line_wordmark(); W = wm["w"]; lines=[wm]; faces=[]
    if tagline: lines.append(line_tag(W))
    if kannada:
        lines.append(line_kn(W, "one400", "VOF Kannada", KN_ONE)); faces=[("VOF Kannada", F400)]
    top, bot = stack(lines)
    shift = OPT*MH - (top+bot)/2        # optically centre the block on the symbol
    mw = MH*SEED_W/SEED_H
    x_text = mw + G_H*X
    uy0, uy1 = min(0.0, top+shift), max(MH, bot+shift)
    m = SAFETY*X
    vw, vh = x_text + W + 2*m, (uy1-uy0) + 2*m
    sy = m - uy0
    body = seed(MH, c, m, sy) + "".join(l["draw"](x_text+m, l["base"]+shift+sy, c) for l in lines)
    info = dict(X=round(X,1), measure=round(W,1), mark_h=round(MH,1), G_h=round(G_H*X,1),
                G_t=round(G_T*X,1), vbox=f"{vw:.0f}x{vh:.0f}")
    return wrap(vw, vh, "Varanashi", faces, body), info

def vertical(c=INK_COL, kannada=True, decorative=False):
    MH = MARK_H*X
    gv = (2.0 if decorative else G_V)*X
    wm = line_wordmark(); W = wm["w"]; lines=[wm, line_tag(W)]; faces=[]
    if kannada:
        lines.append(line_kn(W, "one400", "VOF Kannada", KN_ONE)); faces=[("VOF Kannada", F400)]
    top, bot = stack(lines)
    # G_v is measured from the symbol's bottom to the wordmark's CAP TOP
    shift = MH + gv - wm["cap_top"]
    mw = MH*SEED_W/SEED_H
    width = max(mw, W)
    m = SAFETY*X
    vw, vh = width + 2*m, (bot+shift) + 2*m
    body = (seed(MH, c, m + (width-mw)/2, m)
            + "".join(l["draw"](m + (width-W)/2, l["base"]+shift+m, c) for l in lines))
    return wrap(vw, vh, "Varanashi", faces, body), dict(X=round(X,1), G_v=round(gv,1), vbox=f"{vw:.0f}x{vh:.0f}")

def kannada_only(c=INK_COL):
    MH = MARK_H*X
    fs1 = KN1_INK*X/(KASC+KDESC)
    W = KNW["l1_600"]*fs1
    lines = [line_kn(W, "l1_600", "VOF Kannada Bold", KN1),
             line_kn(W, "l2_600", "VOF Kannada Bold", KN2)]
    top, bot = stack(lines)
    shift = OPT*MH - (top+bot)/2
    mw = MH*SEED_W/SEED_H; x_text = mw + G_H*X
    uy0, uy1 = min(0.0, top+shift), max(MH, bot+shift)
    m = SAFETY*X
    vw, vh = x_text + W + 2*m, (uy1-uy0) + 2*m
    sy = m - uy0
    body = seed(MH, c, m, sy) + "".join(l["draw"](x_text+m, l["base"]+shift+sy, c) for l in lines)
    return wrap(vw, vh, "ವಾರಣಾಶಿ ಸಾವಯವ ತೋಟ", [("VOF Kannada Bold", F600)], body), \
           dict(X=round(X,1), measure=round(W,1), vbox=f"{vw:.0f}x{vh:.0f}")

def mark_only(c=INK_COL):
    MH = MARK_H*X; mw = MH*SEED_W/SEED_H; m = SAFETY*X
    return wrap(mw+2*m, MH+2*m, "Varanashi mark", [], seed(MH, c, m, m))

built, info = {}, {}
for sfx, col in (("", INK_COL), ("-paper", PAPER), ("-current", "currentColor")):
    built[f"varanashi-horizontal{sfx}.svg"],    info["horizontal"]    = horizontal(col)
    built[f"varanashi-horizontal-en{sfx}.svg"], info["horizontal-en"] = horizontal(col, kannada=False)
    built[f"varanashi-wordmark-only{sfx}.svg"], info["wordmark-only"] = horizontal(col, kannada=False, tagline=False)
    built[f"varanashi-kannada{sfx}.svg"],       info["kannada"]       = kannada_only(col)
    built[f"varanashi-vertical{sfx}.svg"],      info["vertical"]      = vertical(col)
    built[f"varanashi-vertical-en{sfx}.svg"],   info["vertical-en"]   = vertical(col, kannada=False)
    built[f"varanashi-mark{sfx}.svg"] = mark_only(col)
for n, d in sorted(built.items()):
    (OUT/n).write_text(d if isinstance(d, str) else d[0])
print(f"{len(built)} files · X = {X}px · G_h = {G_H}X{' (breathable)' if BREATHE else ''}")
for k, v in info.items(): print(f"  {k:<16}{v}")
