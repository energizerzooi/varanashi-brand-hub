#!/usr/bin/env python3
"""Procedural overlay textures for asset-studio: transparent PNGs (black ink, alpha = texture).
Use them over any surface with mix-blend-mode multiply (light grounds) or screen (dark grounds), 8–30% opacity.
  wood_*.png   wood grain (plank, flat-sawn with knots)
  paint_*.png  dry-brush paint strokes (horizontal, diagonal, scumble)
  paper.png    paper tooth
Usage: python3 make_textures.py OUTDIR [size]"""
import sys, math, numpy as np
from PIL import Image
from scipy import ndimage as nd

OUT = sys.argv[1]; S = int(sys.argv[2]) if len(sys.argv) > 2 else 1600
rng = np.random.default_rng(7)

def save(a, name):
    a = np.clip(a, 0, 1)
    rgba = np.zeros((*a.shape, 4), np.uint8); rgba[..., 3] = (a * 255).astype(np.uint8)
    Image.fromarray(rgba, "RGBA").save(f"{OUT}/{name}.png", optimize=True); print(name, a.mean().round(3))

def fbm(h, w, scale, octaves=5, seed=0):
    r = np.random.default_rng(seed); out = np.zeros((h, w))
    for o in range(octaves):
        s = max(1, int(scale / 2 ** o)); n = r.standard_normal((h // s + 2, w // s + 2))
        out += nd.zoom(n, s, order=3)[:h, :w] / 2 ** o
    return (out - out.min()) / (out.max() - out.min())

# ---------- wood grain ----------
def wood(seed, knots=2, rings=46):
    """Flat-sawn plank: long near-parallel grain (vertical), slow waviness, small knots with the grain bending round them."""
    h = w = S; y, x = np.mgrid[0:h, 0:w].astype(float)
    r = np.random.default_rng(seed)
    slow = nd.zoom(r.standard_normal((4, 10)), (h / 4, w / 10), order=3)[:h, :w]      # slow wander across the board
    wav = nd.zoom(r.standard_normal((7, 5)), (h / 7, w / 5), order=3)[:h, :w]      # gentle waviness down the grain
    d = x / w * rings + .9 * slow + .3 * wav
    for _ in range(knots):
        kx, ky = r.uniform(.25, .75) * w, r.uniform(.15, .85) * h; kr = r.uniform(.008, .014) * w
        q = np.hypot(x - kx, (y - ky) / 2.6)
        d += 2.2 * np.exp(-(q / (kr * 3.2)) ** 2) * np.sign(x - kx)                    # grain parts around the knot
        d += np.where(q < kr, (kr - q) / kr * 6, 0)                                      # tight rings inside it
    phase = d % 1.0
    lw = .03 + .05 * nd.zoom(r.random((5, 60)), (h / 5, w / 60), order=1)[:h, :w]
    late = np.exp(-((phase - .5) / lw) ** 2) * (.55 + .45 * nd.zoom(r.random((30, 60)), (h / 30, w / 60), order=1)[:h, :w])                                           # thin dark latewood lines
    early = .25 * (1 - np.abs(phase - .5) * 2)                                           # soft earlywood band
    fibre = nd.gaussian_filter(r.random((h, w)), (14, .6)); fibre = (fibre - fibre.min()) / (fibre.max() - fibre.min())
    a = .7 * late + early + .25 * fibre ** 3
    return np.clip(a, 0, 1) * .85

# ---------- paint strokes ----------
def stroke_layer(h, w, n, width, angle, length, seed, dry=.55):
    r = np.random.default_rng(seed); a = np.zeros((h, w))
    for _ in range(n):
        cx, cy = r.uniform(-.1, 1.1) * w, r.uniform(-.1, 1.1) * h
        L = r.uniform(.6, 1.2) * length; bw = r.uniform(.7, 1.3) * width; ang = math.radians(angle + r.uniform(-8, 8))
        steps = int(L / 2); bristles = int(bw / 2.2)
        offs = r.normal(0, bw / 3, bristles); load = r.uniform(.4, 1, bristles)
        bend = r.uniform(-.25, .25)
        for b in range(bristles):
            t = np.linspace(0, 1, steps)
            px = cx + (t - .5) * L * math.cos(ang) - offs[b] * math.sin(ang) + bend * L * (t - .5) ** 2 * math.sin(ang)
            py = cy + (t - .5) * L * math.sin(ang) + offs[b] * math.cos(ang) - bend * L * (t - .5) ** 2 * math.cos(ang)
            fade = np.clip(1.15 - t ** 1.6, 0, 1) * load[b]          # paint runs out along the stroke
            skip = r.random(steps) > dry * (1 - fade * .6)           # dry-brush gaps
            ix, iy = px.astype(int), py.astype(int); ok = (ix >= 0) & (ix < w) & (iy >= 0) & (iy < h) & skip
            np.add.at(a, (iy[ok], ix[ok]), fade[ok])
    a = nd.gaussian_filter(a, .9)
    return np.clip(a / (np.percentile(a[a > 0], 92) + 1e-6), 0, 1)

def paint(kind, seed):
    h = w = S
    if kind == "horizontal": a = stroke_layer(h, w, 70, 120, 0, 700, seed)
    elif kind == "diagonal": a = stroke_layer(h, w, 80, 110, -32, 650, seed)
    else:  # scumble: short crossing strokes
        a = np.maximum(stroke_layer(h, w, 120, 80, 20, 260, seed), stroke_layer(h, w, 120, 80, -50, 260, seed + 1) * .8)
    tooth = fbm(h, w, 3, 2, seed + 9)
    return np.clip(a * (.75 + .5 * tooth) * .85, 0, 1)

def paper(seed=4):
    h = w = S; t = fbm(h, w, 2, 2, seed) * .5 + fbm(h, w, 30, 3, seed + 1) * .5
    return np.clip((t - .45) * 1.6, 0, 1) * .6

save(wood(1, 2), "wood_plank"); save(wood(2, 3, rings=22), "wood_knots")
save(paint("horizontal", 3), "paint_horizontal"); save(paint("diagonal", 4), "paint_diagonal"); save(paint("scumble", 5), "paint_scumble")
save(paper(), "paper_tooth")
