"""Annotated construction diagrams, generated from the same constants as the lockups."""
import sys, re, importlib.util
from pathlib import Path
spec = importlib.util.spec_from_file_location("bl", "/home/claude/scripts/build_lockup.py")
sys.argv = ["bl", sys.argv[1], "64"]
bl = importlib.util.module_from_spec(spec); spec.loader.exec_module(bl)

OUT = Path(sys.argv[1])/"assets"/"lockups"
X = bl.X; MH = bl.MARK_H*X; mw = MH*bl.SEED_W/bl.SEED_H
RULE, DIM, INKC = "#C9553D", "#8A98A4", "#2C3D52"
F = 'font-family="Quicksand, sans-serif" font-size="21" font-weight="700" letter-spacing="0.05em"'

def arrow(x1,y1,x2,y2,label,vertical=False,col=RULE):
    s=(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{col}" stroke-width="1.5"/>')
    for (px,py) in ((x1,y1),(x2,y2)):
        s+=(f'<line x1="{px-7 if vertical else px:.1f}" y1="{py if vertical else py-7:.1f}" '
            f'x2="{px+7 if vertical else px:.1f}" y2="{py if vertical else py+7:.1f}" stroke="{col}" stroke-width="2"/>')
    mx,my=(x1+x2)/2,(y1+y2)/2
    s+=(f'<rect x="{mx-52:.1f}" y="{my-16:.1f}" width="104" height="32" fill="#F4ECDD"/>'
        f'<text x="{mx:.1f}" y="{my+8:.1f}" text-anchor="middle" fill="{col}" {F}>{label}</text>')
    return s

def guide(x1,y1,x2,y2):
    return (f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{DIM}" '
            f'stroke-width="1" stroke-dasharray="4 4"/>')

def horizontal_diagram():
    wm = bl.line_wordmark(); W = wm["w"]
    lines=[wm, bl.line_tag(W), bl.line_kn(W,"one400","VOF Kannada",bl.KN_ONE)]
    top,bot = bl.stack(lines)
    shift = bl.OPT*MH - (top+bot)/2
    x_text = mw + bl.G_H*X
    PAD = 150
    uy0,uy1 = min(0.0, top+shift), max(MH, bot+shift)
    vw, vh = x_text + W + PAD*2, (uy1-uy0) + PAD*2
    sx, sy = PAD, PAD - uy0
    s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {vw:.0f} {vh:.0f}" width="{vw:.0f}" height="{vh:.0f}">',
       f'<defs><style>@font-face{{font-family:"VOF Kannada";font-weight:400;'
       f'src:url(data:font/ttf;base64,{bl.F400}) format("truetype");}}</style></defs>',
       f'<rect width="{vw:.0f}" height="{vh:.0f}" fill="#F4ECDD"/>']
    # clear space box = 1.0 X around the ink
    cs = X
    s.append(f'<rect x="{sx-cs:.1f}" y="{sy+uy0-cs:.1f}" width="{x_text+W+2*cs:.1f}" '
             f'height="{(uy1-uy0)+2*cs:.1f}" fill="none" stroke="{DIM}" stroke-width="1.5" stroke-dasharray="6 5"/>')
    s.append(bl.seed(MH, INKC, sx, sy))
    for l in lines: s.append(l["draw"](x_text+sx, l["base"]+shift+sy, INKC))
    # guides
    gy = sy + uy1 + 52
    s.append(guide(sx+mw, sy-20, sx+mw, gy+10))
    s.append(guide(sx+x_text, sy-20, sx+x_text, gy+10))
    s.append(arrow(sx+mw, gy, sx+x_text, gy, "G&#8341; 1.0X"))
    # X swatch on the wordmark
    wmb = lines[0]["base"]+shift+sy
    s.append(guide(sx+x_text-40, wmb, sx+x_text+W, wmb))
    s.append(guide(sx+x_text-40, wmb-X, sx+x_text+W, wmb-X))
    s.append(arrow(sx+x_text-24, wmb-X, sx+x_text-24, wmb, "X", vertical=True))
    # G_t: wordmark baseline -> tagline cap top
    tb = lines[1]["base"]+shift+sy; tct = tb + lines[1]["cap_top"]
    s.append(guide(sx+x_text+W, tct, sx+x_text+W+70, tct))
    s.append(guide(sx+x_text+W, wmb, sx+x_text+W+70, wmb))
    s.append(arrow(sx+x_text+W+46, wmb, sx+x_text+W+46, tct, "G&#8348; .75X", vertical=True))
    # clear space label
    s.append(f'<text x="{sx-cs:.1f}" y="{sy+uy0-cs-16:.1f}" fill="{DIM}" {F}>CLEAR SPACE 1.0X</text>')
    s.append('</svg>')
    return "\n".join(s)

def vertical_diagram():
    wm = bl.line_wordmark(); W = wm["w"]
    lines=[wm, bl.line_tag(W), bl.line_kn(W,"one400","VOF Kannada",bl.KN_ONE)]
    top,bot = bl.stack(lines)
    gv = bl.G_V*X
    shift = MH + gv - wm["cap_top"]
    width = max(mw, W); PAD = 150
    vw, vh = width + PAD*2, (bot+shift) + PAD*2
    s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {vw:.0f} {vh:.0f}" width="{vw:.0f}" height="{vh:.0f}">',
       f'<defs><style>@font-face{{font-family:"VOF Kannada";font-weight:400;'
       f'src:url(data:font/ttf;base64,{bl.F400}) format("truetype");}}</style></defs>',
       f'<rect width="{vw:.0f}" height="{vh:.0f}" fill="#F4ECDD"/>']
    cs=X
    s.append(f'<rect x="{PAD-cs:.1f}" y="{PAD-cs:.1f}" width="{width+2*cs:.1f}" height="{bot+shift+2*cs:.1f}" '
             f'fill="none" stroke="{DIM}" stroke-width="1.5" stroke-dasharray="6 5"/>')
    s.append(bl.seed(MH, INKC, PAD+(width-mw)/2, PAD))
    for l in lines: s.append(l["draw"](PAD+(width-W)/2, l["base"]+shift+PAD, INKC))
    cx = PAD+(width-mw)/2 - 46
    capt = wm["base"]+shift+PAD+wm["cap_top"]
    s.append(guide(cx-14, PAD+MH, PAD+width, PAD+MH))
    s.append(guide(cx-14, capt, PAD+width, capt))
    s.append(arrow(cx, PAD+MH, cx, capt, "G&#7515; 1.5X", vertical=True))
    s.append(f'<text x="{PAD-cs:.1f}" y="{PAD-cs-16:.1f}" fill="{DIM}" {F}>CLEAR SPACE 1.0X</text>')
    s.append('</svg>')
    return "\n".join(s)

(OUT/"diagram-horizontal.svg").write_text(horizontal_diagram())
(OUT/"diagram-vertical.svg").write_text(vertical_diagram())
print("diagrams written")
print(f"  X={X}  mark_h={MH:.1f}  G_h={bl.G_H*X:.1f}  G_v={bl.G_V*X:.1f}  G_t={bl.G_T*X:.1f}  clear={X:.1f}")
