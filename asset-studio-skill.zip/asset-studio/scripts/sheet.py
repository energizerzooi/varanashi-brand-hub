#!/usr/bin/env python3
"""Contact sheet: python3 sheet.py out.jpg a.png:"label" b.png:"label" ... [--cols 4] [--w 420]
Labels sit under each tile. Use the direction's genome as the label (e.g. "A · S2 B1 C3 I1 V2 D1")."""
import sys
from PIL import Image, ImageDraw, ImageFont
args = sys.argv[2:]; cols, tw = 4, 420
if "--cols" in args: i = args.index("--cols"); cols = int(args[i + 1]); del args[i:i + 2]
if "--w" in args: i = args.index("--w"); tw = int(args[i + 1]); del args[i:i + 2]
items = [(a.split(":", 1) + [""])[:2] for a in args]
ims = [Image.open(p).convert("RGB") for p, _ in items]
th = max(int(im.height * tw / im.width) for im in ims); pad, lab = 24, 44
rows = -(-len(ims) // cols)
S = Image.new("RGB", (pad + cols * (tw + pad), pad + rows * (th + lab + pad)), (240, 236, 230))
d = ImageDraw.Draw(S)
try: f = ImageFont.truetype("DejaVuSans.ttf", 17)
except Exception: f = ImageFont.load_default()
for k, (im, (_, l)) in enumerate(zip(ims, items)):
    r, c = divmod(k, cols); x, y = pad + c * (tw + pad), pad + r * (th + lab + pad)
    S.paste(im.resize((tw, int(im.height * tw / im.width)), Image.LANCZOS), (x, y))
    d.text((x, y + th + 10), l, fill=(40, 40, 40), font=f)
S.save(sys.argv[1], quality=90); print(sys.argv[1], S.size)
