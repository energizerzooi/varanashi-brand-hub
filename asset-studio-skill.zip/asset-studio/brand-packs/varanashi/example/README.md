# Worked example · swim workshop poster

The run that proved the loop, 25 November 2026. Instagram 4:5, English, photo-led.

| File | What it is |
|---|---|
| `swim-poster.jpg` | the finished poster, 1080×1350 at 2× |
| `swim-poster.html` | its source — read this to see how the parts fit |
| `swim-graded.jpg` | the farm's photograph after the house archive grade |
| `band.jpg` | the crop used inside the torn band |
| `paper.png` | the paper-fibre grain, multiplied over everything |
| `torn.txt` | the three deckle edges as point lists |

## What the run cost, and why the loop looks the way it does

**Round one was bland.** Ten comps, every matrix quadrant covered, and all ten were the
same layout recoloured: title top-left, typewriter facts, call to action at the foot.
Spread across coordinates had been satisfied while range of ideas had not. The move
codes were printed on the labels and not executed in the artwork.

**Round two was photo-led and loud**, after the farm said so. Structurally different
layouts, real textures, the full type cast. It also broke the spread rule — nearly
everything landed in the graphic half — which is correct when a direction has been
stated, and is now written into step 4.

**The refinement found two faults no amount of looking would have caught.** A crop ran
past the bottom edge of the source photograph, so PIL padded it black and four comps
carried black bars. And contrast computed on flat swatches read 5.9:1 while the same
text measured on rendered pixels read 4.04:1, because the grain layer had darkened the
ground beneath it. `lint.js` found six issues in all, including a drift off-palette into
invented oranges.

## Reproduce it

```
node scripts/lint.js example/swim-poster.html --pack brand-packs/varanashi/brand.json --out lintout
```

Expect one fail and two warnings, all three deliberate and explained in the reply that
delivered the poster: the gold chip aligns on its edge rather than its label; right-aligned
columns create their own left axes; and the photograph bleeding into the torn edges reads
as off-palette pixels.
