import random, json, math
random.seed(1125)
F="/home/claude/build/asset-studio/brand-packs/varanashi/assets"
T=F+"/textures"
C=dict(lw="#F9E6D6",lw1="#FBEDDF",lw2="#FBF2E9",lwd="#E6CCB8",mist="#C7D5DE",mistl="#E1E9EF",
mistd="#445C75",sun="#E47444",apr="#EDB180",sunl="#FFDAB6",sund="#AC492B",gold="#F6C463",
goldl="#FFECBA",slate="#2C3D52",slated="#1B2535",lichen="#B9BA9A",lichend="#595C33",
indigo="#24315E",areca="#2E4733",lichenl="#DEE0CF",db="#9BB6C4",dbl="#CFDFE8",
olive="#A6B270",olivel="#DCE0BF",oliveD="#4C5428",sienna="#A55438",paper="#F4ECDD",
ink="#1F2A36",rose="#F0AFA2",sprout="#A7B957")
K="VARANASHI ORGANIC FARMS"
T3="The spring"; B3="It runs all year, through the dry months when the wells around it fall."

def blobpath(seed,w,h,n=9,wob=.30):
    r=random.Random(seed); cx,cy=w/2,h/2; rx,ry=w/2*.99,h/2*.99
    pts=[]
    for i in range(n):
        a=2*math.pi*i/n; k=1-wob/2+r.random()*wob
        pts.append((cx+math.cos(a)*rx*k, cy+math.sin(a)*ry*k))
    d=f"M {pts[0][0]:.1f} {pts[0][1]:.1f} "
    for i in range(n):
        p0,p1,p2,pm=pts[i],pts[(i+1)%n],pts[(i+2)%n],pts[i-1]
        c1=(p0[0]+(p1[0]-pm[0])/4,p0[1]+(p1[1]-pm[1])/4)
        c2=(p1[0]-(p2[0]-p0[0])/4,p1[1]-(p2[1]-p0[1])/4)
        d+=f"C {c1[0]:.1f} {c1[1]:.1f}, {c2[0]:.1f} {c2[1]:.1f}, {p1[0]:.1f} {p1[1]:.1f} "
    return d+"Z"

def tornpoly(seed,amp=26,n=38):
    r=random.Random(seed); pts=[]
    for i in range(n+1):
        t=i/n
        y=r.uniform(-amp,amp)+r.choice([0,0,0,amp*0.7])*r.random()
        pts.append(f"{t*100:.2f}% {amp+y:.1f}px")
    return "polygon("+",".join(pts)+",100% 100%,0% 100%)"

HEAD=f"""<!DOCTYPE html><html><head><meta charset="utf-8"><style>
@font-face{{font-family:Nazm;src:url('{F}/ST-Nazm-Variable.ttf');font-weight:100 1200;}}
@font-face{{font-family:Sentient;src:url('{F}/Sentient-Variable.ttf');font-weight:200 700;}}
@font-face{{font-family:SentientI;src:url('{F}/Sentient-VariableItalic.ttf');font-weight:200 700;}}
@font-face{{font-family:Quick;src:url('{F}/Quicksand-Variable.ttf');font-weight:300 700;}}
@font-face{{font-family:Zyntra;src:url('{F}/ZyntraDoodle-Regular.otf');}}
@font-face{{font-family:Courier;src:url('{F}/courier-prime-latin-400-normal.woff2');}}
@font-face{{font-family:Gaegu;src:url('{F}/gaegu-latin-700-normal.woff2');font-weight:700;}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:#555;display:flex;flex-wrap:wrap}}
.slide{{width:1080px;height:1080px;position:relative;overflow:hidden;flex:none}}
.grain{{position:absolute;inset:0;background-image:url('{T}/paper_tooth.png');background-size:700px;
 mix-blend-mode:multiply;opacity:.28;pointer-events:none;z-index:90}}
img{{display:block}} .ph{{position:absolute;object-fit:cover}}
</style></head><body>"""
S=[]
def sl(i): return f'<div class="slide">{i}<div class="grain"></div></div>'

# 1 GRID SCRAPBOOK — title given its own clear zone, stronger grid, no collisions
grid=f"background-color:{C['lw2']};background-image:linear-gradient({C['db']}88 1px,transparent 1px),linear-gradient(90deg,{C['db']}88 1px,transparent 1px);background-size:48px 48px"
def pol(src,x,y,w,rot,cap=None,ar=1.18):
    h=int(w*ar); pb=56 if cap else 16
    c=f'<div style="position:absolute;left:0;right:0;bottom:14px;text-align:center;font:700 25px Gaegu;color:{C["slate"]}">{cap}</div>' if cap else ""
    return (f'<div style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h+pb-16}px;background:#fff;'
      f'padding:16px 16px {pb}px;transform:rotate({rot}deg);box-shadow:0 12px 30px #0003">'
      f'<img src="img/{src}" style="width:100%;height:{h-32}px;object-fit:cover">{c}</div>')
d1a=(f'<div style="position:absolute;inset:0;{grid}"></div>'
 f'<svg style="position:absolute;left:-60px;top:60px" width="820" height="640"><path d="{blobpath(3,820,640)}" fill="{C["olive"]}"/></svg>'
 + pol("spring.jpg",120,130,430,-5,"the spring")
 + pol("sprout.jpg",610,250,230,8)
 + pol("calf.jpg",620,560,280,-10,"a neighbour")
 + f'<div style="position:absolute;left:84px;top:760px;width:500px;font:300 74px/0.98 Sentient;color:{C["slate"]}">Sixty per cent<br>is <em style="font-family:SentientI">not farmed</em></div>'
 + f'<div style="position:absolute;left:88px;top:52px;font:26px Zyntra;color:{C["sun"]}">{K}</div>')
d1b=(f'<div style="position:absolute;inset:0;{grid}"></div>'
 f'<svg style="position:absolute;right:-80px;top:-60px" width="640" height="560"><path d="{blobpath(9,640,560)}" fill="{C["dbl"]}"/></svg>'
 + pol("paddy.jpg",110,180,540,3)
 + f'<div style="position:absolute;left:112px;top:800px;font:300 88px Sentient;color:{C["slate"]}">{T3}</div>'
 + f'<div style="position:absolute;left:116px;top:906px;width:600px;font:500 26px/1.45 Quick;color:{C["mistd"]}">{B3}</div>'
 + f'<div style="position:absolute;right:92px;top:92px;font:30px Zyntra;color:{C["sun"]};transform:rotate(8deg)">03</div>')
S+=[("1 · Grid scrapbook",d1a),("1 · Grid scrapbook",d1b)]

# 2 FULL BLEED
def fb(src,title,kick,body=None):
    b=f'<div style="position:absolute;left:84px;bottom:96px;width:700px;font:500 27px/1.5 Quick;color:#fff;opacity:.9">{body}</div>' if body else ""
    off=186 if body else 100
    return (f'<img class="ph" src="img/{src}" style="inset:0;width:1080px;height:1080px">'
      f'<div style="position:absolute;inset:0;background:linear-gradient(to top,{C["slated"]}e6 0%,{C["slated"]}60 40%,transparent 68%)"></div>'
      f'<div style="position:absolute;left:84px;bottom:{off}px;width:800px;font:300 84px/1.02 Nazm;color:#fff">{title}</div>'
      f'<div style="position:absolute;left:88px;top:80px;font:700 19px Quick;letter-spacing:.2em;color:#fff;opacity:.82">{kick}</div>{b}')
S+=[("2 · Full bleed, corner type",fb("cottage.jpg","Sixty per cent of this<br>farm is not farmed",K)),
    ("2 · Full bleed, corner type",fb("forest.jpg",T3,"03 — WATER",B3))]

# 3 TORN STACK — photo gets real room, tear amplitude readable, two offset layers
def tr(src,title,sub,sheet,ink):
    return (f'<img class="ph" src="img/{src}" style="inset:0;width:1080px;height:1080px">'
      f'<div style="position:absolute;left:0;right:0;top:520px;height:620px;background:{sheet};clip-path:{tornpoly(7,30)};box-shadow:0 -14px 36px #0003"></div>'
      f'<div style="position:absolute;left:0;right:0;top:578px;height:580px;background:{C["paper"]};clip-path:{tornpoly(21,24)}"></div>'
      f'<div style="position:absolute;left:88px;top:672px;width:880px;font:400 86px/1.02 Nazm;color:{ink}">{title}</div>'
      f'<div style="position:absolute;left:92px;bottom:92px;width:720px;font:500 27px/1.5 Quick;color:{C["mistd"]}">{sub}</div>')
S+=[("3 · Torn paper stack",tr("paddy.jpg","Sixty per cent<br>is not farmed",K,C["apr"],C["slate"])),
    ("3 · Torn paper stack",tr("spring.jpg",T3,B3,C["gold"],C["areca"]))]

# 4 FIELD NOTEBOOK — invented coordinates removed, photo enlarged
rule=f"background-color:{C['paper']};background-image:repeating-linear-gradient(transparent,transparent 47px,{C['mist']}77 47px,{C['mist']}77 48px)"
def tape(x,y,rot): return f'<div style="position:absolute;left:{x}px;top:{y}px;width:128px;height:34px;background:{C["goldl"]}dd;transform:rotate({rot}deg);box-shadow:0 3px 8px #0002;z-index:5"></div>'
d4a=(f'<div style="position:absolute;inset:0;{rule}"></div>'
 f'<div style="position:absolute;left:132px;top:0;bottom:0;width:2px;background:{C["rose"]}bb"></div>'
 f'<div style="position:absolute;left:180px;top:66px;font:400 21px Courier;color:{C["mistd"]};letter-spacing:.1em">{K} · PLOT NOTES</div>'
 f'<img class="ph" src="img/seedling.jpg" style="left:180px;top:132px;width:720px;height:440px">'
 + tape(300,114,-3)+tape(740,114,4)
 + f'<div style="position:absolute;left:180px;top:600px;font:400 20px Courier;color:{C["mistd"]}">fig. 1 — new planting, october</div>'
 + f'<div style="position:absolute;left:180px;top:672px;width:780px;font:400 80px/1.04 Nazm;color:{C["slate"]}">Sixty per cent<br>is not farmed</div>')
d4b=(f'<div style="position:absolute;inset:0;{rule}"></div>'
 f'<div style="position:absolute;left:132px;top:0;bottom:0;width:2px;background:{C["rose"]}bb"></div>'
 f'<div style="position:absolute;left:180px;top:66px;font:400 21px Courier;color:{C["mistd"]};letter-spacing:.1em">03 — WATER</div>'
 f'<div style="position:absolute;left:178px;top:116px;font:400 100px Nazm;color:{C["slate"]}">{T3}</div>'
 f'<img class="ph" src="img/spring.jpg" style="left:180px;top:286px;width:720px;height:470px">'
 + tape(480,268,3)
 + f'<div style="position:absolute;left:180px;top:800px;width:720px;font:400 23px/2.0 Courier;color:{C["slate"]}">{B3}</div>')
S+=[("4 · Field notebook",d4a),("4 · Field notebook",d4b)]

# 5 ONE BIG WORD — numeral and photo no longer collide; word fits the frame
d5a=(f'<div style="position:absolute;inset:0;background:{C["lw"]}"></div>'
 f'<div style="position:absolute;left:0;right:0;top:92px;font:700 360px/0.8 Nazm;color:{C["sun"]};text-align:center;letter-spacing:-.04em">60<span style="font-size:140px">%</span></div>'
 f'<div style="position:absolute;left:0;right:0;top:430px;text-align:center;font:300 58px/1.12 Sentient;color:{C["slate"]}">of this farm<br>is not farmed</div>'
 f'<img class="ph" src="img/beans.jpg" style="left:0;top:660px;width:1080px;height:420px">'
 f'<div style="position:absolute;left:0;right:0;top:44px;text-align:center;font:700 19px Quick;letter-spacing:.22em;color:{C["lichend"]}">{K}</div>')
d5b=(f'<div style="position:absolute;inset:0;background:{C["areca"]}"></div>'
 f'<div style="position:absolute;left:0;right:0;top:110px;font:700 212px/0.86 Nazm;color:{C["gold"]};text-align:center;letter-spacing:-.02em">SPRING</div>'
 f'<img class="ph" src="img/spring.jpg" style="left:90px;top:400px;width:900px;height:450px">'
 f'<div style="position:absolute;left:92px;top:890px;width:800px;font:500 29px/1.5 Quick;color:{C["goldl"]}">{B3}</div>')
S+=[("5 · One big word",d5a),("5 · One big word",d5b)]

# 6 TILE GRID — caption collision fixed
def tile(src,cap,x,y,w=440,h=440):
    return (f'<img class="ph" src="img/{src}" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px">'
      f'<div style="position:absolute;left:{x}px;top:{y+h+11}px;width:{w}px;font:700 18px Quick;letter-spacing:.11em;color:{C["slate"]}">{cap}</div>')
d6a=(f'<div style="position:absolute;inset:0;background:{C["lw1"]}"></div>'
 f'<div style="position:absolute;left:80px;top:64px;width:900px;font:400 58px/1.06 Nazm;color:{C["slate"]}">Sixty per cent of this<br>farm is not farmed</div>'
 + tile("spring.jpg","01 THE SPRING",80,236)+tile("forest.jpg","02 THE FOREST",560,236)
 + tile("cacao.jpg","03 THE CACAO",80,730,440,230)+tile("calf.jpg","04 THE HERD",560,730,440,230)
 + f'<div style="position:absolute;left:80px;bottom:28px;font:700 17px Quick;letter-spacing:.2em;color:{C["lichend"]}">{K}</div>')
d6b=(f'<div style="position:absolute;inset:0;background:{C["lw1"]}"></div>'
 f'<div style="position:absolute;left:80px;top:64px;font:400 72px Nazm;color:{C["slate"]}">{T3}</div>'
 f'<div style="position:absolute;left:84px;top:162px;width:620px;font:500 25px/1.5 Quick;color:{C["mistd"]}">{B3}</div>'
 + tile("spring.jpg","JANUARY",80,286,440,320)+tile("paddy.jpg","APRIL",560,286,440,320)
 + tile("roots.jpg","AUGUST",80,668,440,300)+tile("fungus.jpg","NOVEMBER",560,668,440,300))
S+=[("6 · Tile grid",d6a),("6 · Tile grid",d6b)]

# 7 BLOB MASKS — real organic paths
def bm(src,x,y,w,h,seed):
    return (f'<div style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;'
      f'clip-path:path(\'{blobpath(seed,w,h)}\')"><img src="img/{src}" style="width:100%;height:100%;object-fit:cover"></div>')
d7a=(f'<div style="position:absolute;inset:0;background:{C["sun"]}"></div>'
 + bm("cacao.jpg",120,120,660,660,11) + bm("sprout.jpg",700,540,250,320,17)
 + f'<div style="position:absolute;left:100px;top:840px;width:880px;font:300 76px/1.0 Sentient;color:{C["lw2"]}">Sixty per cent<br>is not farmed</div>'
 + f'<div style="position:absolute;left:104px;top:60px;font:700 19px Quick;letter-spacing:.22em;color:{C["sunl"]}">{K}</div>')
d7b=(f'<div style="position:absolute;inset:0;background:{C["indigo"]}"></div>'
 + bm("spring.jpg",80,220,920,540,23)
 + f'<div style="position:absolute;left:0;right:0;top:84px;text-align:center;font:300 92px Sentient;color:{C["gold"]}">{T3}</div>'
 + f'<div style="position:absolute;left:160px;top:830px;width:760px;text-align:center;font:500 27px/1.5 Quick;color:{C["dbl"]}">{B3}</div>')
S+=[("7 · Blob masks on flat",d7a),("7 · Blob masks on flat",d7b)]

# 8 HORIZON BAND
def band(src,title,body,col,ink,h=560):
    return (f'<img class="ph" src="img/{src}" style="left:0;top:0;width:1080px;height:{h}px">'
      f'<div style="position:absolute;left:0;right:0;top:{h}px;bottom:0;background:{col}"></div>'
      f'<div style="position:absolute;left:84px;top:{h+64}px;width:880px;font:400 76px/1.05 Nazm;color:{ink}">{title}</div>'
      f'<div style="position:absolute;left:88px;bottom:72px;width:740px;font:500 26px/1.5 Quick;color:{ink};opacity:.8">{body}</div>')
S+=[("8 · Horizon band",band("spring.jpg","Sixty per cent of this<br>farm is not farmed",K,C["lw"],C["slate"])),
    ("8 · Horizon band",band("cottage.jpg",T3,B3,C["areca"],C["lw2"]))]

# 9 STAMP / ROUNDEL — roundel clear of the photo edge
def rd(n,x,y,d,col,ink):
    return (f'<div style="position:absolute;left:{x}px;top:{y}px;width:{d}px;height:{d}px;border-radius:50%;background:{col};'
      f'display:flex;align-items:center;justify-content:center;font:{int(d*.5)}px Zyntra;color:{ink};line-height:1;z-index:6">{n}</div>')
d9a=(f'<div style="position:absolute;inset:0;background:{C["paper"]}"></div>'
 f'<img class="ph" src="img/calf.jpg" style="left:0;top:0;width:1080px;height:470px">'
 + rd("60",740,520,250,C["sun"],C["lw2"])
 + f'<div style="position:absolute;left:88px;top:540px;width:600px;font:400 80px/1.04 Nazm;color:{C["slate"]}">Sixty per<br>cent is not<br>farmed</div>'
 + f'<div style="position:absolute;left:92px;bottom:76px;font:26px Zyntra;color:{C["lichend"]}">{K}</div>')
d9b=(f'<div style="position:absolute;inset:0;background:{C["lichenl"]}"></div>'
 + rd("03",80,74,200,C["areca"],C["gold"])
 + f'<div style="position:absolute;left:320px;top:112px;font:400 104px Nazm;color:{C["areca"]}">{T3}</div>'
 + f'<img class="ph" src="img/cacao.jpg" style="left:80px;top:340px;width:920px;height:460px">'
 + f'<div style="position:absolute;left:84px;top:850px;width:800px;font:500 28px/1.5 Quick;color:{C["oliveD"]}">{B3}</div>')
S+=[("9 · Stamp & roundel",d9a),("9 · Stamp & roundel",d9b)]

# 10 DUOTONE RISO — subline contrast fixed (was gold on gold)
d10a=(f'<div style="position:absolute;inset:0;background:{C["slated"]}"></div>'
 f'<img class="ph" src="img/spring-duo.jpg" style="inset:0;width:1080px;height:1080px">'
 f'<div style="position:absolute;left:0;right:0;top:0;bottom:0;background:linear-gradient(to bottom,{C["slated"]}00 30%,{C["slated"]}cc 62%,{C["slated"]}f2 100%)"></div>'
 f'<div style="position:absolute;left:0;right:0;top:530px;text-align:center;font:700 142px/0.94 Nazm;color:{C["lw2"]}">SIXTY<br>PER CENT</div>'
 f'<div style="position:absolute;left:0;right:0;top:830px;text-align:center;font:500 29px Quick;color:{C["gold"]};letter-spacing:.06em">of this farm is not farmed</div>'
 f'<div style="position:absolute;left:0;right:0;bottom:62px;text-align:center;font:700 18px Quick;letter-spacing:.24em;color:{C["lw2"]};opacity:.7">{K}</div>')
d10b=(f'<div style="position:absolute;inset:0;background:{C["sund"]}"></div>'
 f'<img class="ph" src="img/forest-duo.jpg" style="inset:0;width:1080px;height:1080px;mix-blend-mode:multiply">'
 f'<div style="position:absolute;left:0;right:0;top:0;height:420px;background:linear-gradient(to bottom,{C["sund"]}e0,{C["sund"]}00)"></div>'
 f'<div style="position:absolute;left:0;right:0;bottom:0;height:380px;background:linear-gradient(to top,{C["sund"]}e8,{C["sund"]}00)"></div>'
 f'<div style="position:absolute;left:80px;top:86px;font:700 126px Nazm;color:{C["goldl"]}">{T3}</div>'
 f'<div style="position:absolute;left:84px;bottom:100px;width:800px;font:500 29px/1.5 Quick;color:{C["goldl"]}">{B3}</div>')
S+=[("10 · Duotone riso",d10a),("10 · Duotone riso",d10b)]

open("comps.html","w").write(HEAD+"".join(sl(h) for _,h in S)+"</body></html>")
json.dump([n for n,_ in S],open("names.json","w"))
print("slides:",len(S))
