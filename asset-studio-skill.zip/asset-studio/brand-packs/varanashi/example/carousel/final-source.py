import random, math, json
random.seed(451)
F="/home/claude/build/asset-studio/brand-packs/varanashi/assets"; T=F+"/textures"
C=dict(lw2="#FBF2E9",db="#9BB6C4",dbl="#CFDFE8",olive="#A6B270",olivel="#DCE0BF",
slate="#2C3D52",mistd="#445C75",sun="#E47444",gold="#F6C463",areca="#2E4733",
lichend="#595C33",rose="#F0AFA2",apr="#EDB180",paper="#F4ECDD",sunl="#FFDAB6")
def blobpath(seed,w,h,n=9,wob=.30):
    r=random.Random(seed); cx,cy=w/2,h/2; rx,ry=w/2*.99,h/2*.99
    pts=[(cx+math.cos(2*math.pi*i/n)*rx*(1-wob/2+r.random()*wob),
          cy+math.sin(2*math.pi*i/n)*ry*(1-wob/2+r.random()*wob)) for i in range(n)]
    d=f"M {pts[0][0]:.1f} {pts[0][1]:.1f} "
    for i in range(n):
        p0,p1,p2,pm=pts[i],pts[(i+1)%n],pts[(i+2)%n],pts[i-1]
        d+=(f"C {p0[0]+(p1[0]-pm[0])/4:.1f} {p0[1]+(p1[1]-pm[1])/4:.1f}, "
            f"{p1[0]-(p2[0]-p0[0])/4:.1f} {p1[1]-(p2[1]-p0[1])/4:.1f}, {p1[0]:.1f} {p1[1]:.1f} ")
    return d+"Z"
GRID=f"background-color:{C['lw2']};background-image:linear-gradient({C['db']}88 1px,transparent 1px),linear-gradient(90deg,{C['db']}88 1px,transparent 1px);background-size:48px 48px"
HEAD=f"""<!DOCTYPE html><html><head><meta charset="utf-8"><style>
@font-face{{font-family:Sentient;src:url('{F}/Sentient-Variable.ttf');font-weight:200 700;}}
@font-face{{font-family:SentientI;src:url('{F}/Sentient-VariableItalic.ttf');font-weight:200 700;}}
@font-face{{font-family:Quick;src:url('{F}/Quicksand-Variable.ttf');font-weight:300 700;}}
@font-face{{font-family:Zyntra;src:url('{F}/ZyntraDoodle-Regular.otf');}}
@font-face{{font-family:Gaegu;src:url('{F}/gaegu-latin-700-normal.woff2');font-weight:700;}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:#555;display:flex;flex-wrap:wrap}}
.slide{{width:1080px;height:1080px;position:relative;overflow:hidden;flex:none}}
.grain{{position:absolute;inset:0;background-image:url('{T}/paper_tooth.png');background-size:700px;
 mix-blend-mode:multiply;opacity:.26;z-index:90;pointer-events:none}}
img{{display:block}}
.pol{{position:absolute;background:#fff;box-shadow:0 12px 30px #0003}}
.pol img{{width:100%;object-fit:cover}}
.cap{{position:absolute;left:0;right:0;bottom:15px;text-align:center;font:700 26px Gaegu;color:#2C3D52}}
.ttl{{font-family:Sentient;font-weight:300;color:#2C3D52;line-height:0.98}}
.bod{{font:500 26px/1.46 Quick;color:#445C75}}
.kick{{font:26px Zyntra;color:#E47444}}
.num{{position:absolute;font:30px Zyntra;color:#E47444}}
</style></head><body>"""
def pol(src,x,y,w,ih,rot,cap=None):
    pb=58 if cap else 16
    c=f'<div class="cap">{cap}</div>' if cap else ""
    return (f'<div class="pol" style="left:{x}px;top:{y}px;width:{w}px;padding:16px 16px {pb}px;'
            f'transform:rotate({rot}deg)"><img src="img/{src}" style="height:{ih}px">{c}</div>')
def bl(seed,x,y,w,h,col):
    return f'<svg style="position:absolute;left:{x}px;top:{y}px" width="{w}" height="{h}"><path d="{blobpath(seed,w,h)}" fill="{col}"/></svg>'

S=[]
# 1 OPENER
S.append(f'<div style="position:absolute;inset:0;{GRID}"></div>'
 + bl(3,-70,70,840,650,C["olive"])
 + pol("spring.jpg",118,128,430,330,-5,"the spring")
 + pol("sprout.jpg",612,248,228,268,8)
 + pol("calf.jpg",616,556,282,218,-10,"a neighbour")
 + f'<div class="ttl" style="position:absolute;left:84px;top:762px;width:520px;font-size:74px">Sixty per cent<br>is <em style="font-family:SentientI">not farmed</em></div>'
 + f'<div class="kick" style="position:absolute;left:88px;top:52px">VARANASHI ORGANIC FARMS</div>')
# 2 THE FOREST — blob behind type, cluster fills upper field
S.append(f'<div style="position:absolute;inset:0;{GRID}"></div>'
 + bl(14,470,560,700,620,C["olivel"])
 + pol("forest.jpg",96,150,480,560,3)
 + pol("roots.jpg",604,166,340,300,-7,"old wood")
 + pol("fungus.jpg",640,520,300,232,6)
 + f'<div class="ttl" style="position:absolute;left:96px;top:782px;font-size:88px">The forest</div>'
 + f'<div class="bod" style="position:absolute;left:100px;top:890px;width:560px">A hundred acres on the Karnataka–Kerala border. Most of it we leave standing.</div>'
 + f'<div class="num" style="right:88px;top:92px;transform:rotate(-7deg)">02</div>')
# 3 THE SPRING — single large polaroid, blob anchors the empty corner
S.append(f'<div style="position:absolute;inset:0;{GRID}"></div>'
 + bl(9,540,-90,620,540,C["dbl"])
 + pol("spring.jpg",104,176,560,400,3)
 + pol("paddy.jpg",668,430,272,210,-8,"the paddy")
 + f'<div class="ttl" style="position:absolute;left:104px;top:742px;font-size:88px">The spring</div>'
 + f'<div class="bod" style="position:absolute;left:108px;top:852px;width:600px">It runs all year, through the dry months when the wells around it fall.</div>'
 + f'<div class="num" style="right:92px;top:92px;transform:rotate(8deg)">03</div>')
# 4 WHAT IT GROWS — four fragments, tight cluster
S.append(f'<div style="position:absolute;inset:0;{GRID}"></div>'
 + bl(27,-110,420,760,700,C["sunl"])
 + pol("cacao.jpg",98,132,360,330,-6,"cacao")
 + pol("beans.jpg",490,108,320,290,5,"long beans")
 + pol("seedling.jpg",640,440,300,260,-4)
 + pol("sprout.jpg",128,470,236,250,7)
 + f'<div class="ttl" style="position:absolute;left:92px;top:812px;font-size:80px">What it grows</div>'
 + f'<div class="bod" style="position:absolute;left:96px;top:918px;width:540px">Cacao, rice, pepper, areca, beans — and most of what we eat.</div>'
 + f'<div class="num" style="right:88px;top:92px;transform:rotate(-5deg)">04</div>')
# 5 CLOSER — one wide polaroid, generous air, no ask
S.append(f'<div style="position:absolute;inset:0;{GRID}"></div>'
 + bl(41,180,560,780,540,C["olive"])
 + pol("cottage.jpg",150,140,780,470,-2)
 + f'<div class="ttl" style="position:absolute;left:0;right:0;top:720px;text-align:center;font-size:72px">Two hundred years.<br>One family.<br>Still learning.</div>'
 + f'<div class="kick" style="position:absolute;left:0;right:0;bottom:70px;text-align:center">VARANASHI ORGANIC FARMS</div>')

open("final.html","w").write(HEAD+"".join(f'<div class="slide">{s}<div class="grain"></div></div>' for s in S)+"</body></html>")
print("slides",len(S))
