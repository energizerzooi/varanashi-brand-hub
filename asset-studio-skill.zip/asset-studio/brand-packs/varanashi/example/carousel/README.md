# Worked example 2 — "Something about the land" carousel

Instagram, 1080×1080, five slides, English. Run 25 November 2026, immediately after the
swim poster, to test what a single poster could not: multi-slide structure, caption rhythm
across tiles, and the Canva production path.

## What the brief settled, and what it did not

The farm supplied a reference — a scrapbook-style carousel on grid paper, with olive
organic blobs, rotated photo frames and a display serif. It was read as **rhythm**, never
as artwork: no element of it was traced, sampled or reused.

Eight photographs arrived at step 3. They came through WhatsApp, which recompresses, and
that was worth measuring rather than assuming: the spring at 1280×720 needs a 1.5× upscale
to fill a 1080 square, the cacao sprout at 499×750 is a small fragment only. The collage
direction turned out to be forgiving — fragments are small by nature — but the full-bleed
bookends would have been visibly soft. **Originals off the camera were requested and the
limitation stated rather than hidden.**

The facts were never supplied. The farm's instruction was explicit: *"this is a test of
layouts and visual design, not factual accuracy."* So the copy here is **placeholder and
is marked as such everywhere it appears** — sixty per cent, a hundred acres, two hundred
years, the spring running all year are all unverified. `ten-directions.jpg` and the five
slides must not be published as written. This is the one circumstance in which the assets
gate yields: the person waived it knowingly, for a layout exercise, and the waiver is
recorded instead of being quietly assumed.

## What each round cost

**Round 1 — ten directions.** Rendered, then examined before sending. Four had execution
bugs: a torn-paper edge that read as a thin ribbon, a numeral colliding with its headline,
a word overflowing the frame, and gold type on a gold duotone. Worse, all ten used the
same photograph — ten structurally different layouts that read as one idea restated. Both
were fixed before the farm saw anything. **That is the whole point of step 6.** Sending it
as first rendered would have cost a full round, exactly as it did on the swim poster.

**Round 2 — the pick.** Direction 1 chosen. Extending it to five slides surfaced two
content errors in the studio's own build: slide 3 was titled "The spring" but carried the
paddy photograph, and slide 4 placed a bracket fungus among things that grow. Neither is
visible to the linter. Both were caught by looking at the rendered strip and reading each
headline against its own picture.

**Round 3 — production.** Blocked. See the Canva precondition in `SKILL.md` §1.2.

## The files

| | |
|---|---|
| `ten-directions.jpg` | the contact sheet as sent, after self-critique |
| `comps-source.py` | generator for all ten directions, both slides each |
| `slide-1…5.jpg` | the chosen direction, built out |
| `final-source.py` | generator for the five slides |

The ten directions are kept deliberately. A future job wanting horizon bands, tile grids
or a field-notebook ground starts from working code rather than from a description.
