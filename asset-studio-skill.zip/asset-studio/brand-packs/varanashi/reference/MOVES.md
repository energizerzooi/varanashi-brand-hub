# The move set

Distilled once from the three direction boards in `boards/`. This replaces per-job
browsing: the studio reads this, not Pinterest or Cosmos, unless the farm asks for a
live round.

**The rule that governs all of it.** A move is a verb, not a picture. "Objects scattered
on one strong ground" is a move. The particular poster on the board that does it is not
yours to rebuild. If a draft could be mistaken for a specific board piece, throw it away
and use the move differently.

Each direction in a round cites one or two moves by name, and says where it sits on the
matrix. Two directions may not cite the same pair.

## Structure

| # | Move | Where it lives |
|---|---|---|
| S1 | One big word, everything else small | print-graphic, digital-graphic |
| S2 | Strict column grid with visible rules | print-informative |
| S3 | Equal tiles, one idea each, repeated | digital-informative |
| S4 | Window: a photograph cropped to a shape, type outside it | any |
| S5 | Field and object: one cut-out thing on an open ground | digital-graphic |
| S6 | Annotated drawing with labelled leaders | print-informative |
| S7 | Stamp or seal as the whole composition | print-graphic |
| S8 | Ledger: ruled rows, figures aligned on a decimal | print-informative |
| S9 | Edge-to-edge pattern with one plain panel cut into it | any |
| S10 | Stacked bands, each a different ground, type crossing them | digital-graphic |
| S11 | Scrapbook: framed photographs rotated a few degrees over a drawn ground — graph grid, ruled sheet, or an organic shape behind them | digital-informative, digital-graphic |
| S12 | Torn stack: layered sheets with torn edges, the photograph showing through the gap | print-graphic |
| S13 | Blob mask: photographs clipped to organic bezier shapes on one flat ground | digital-graphic |

S11–S13 were built and tested on the land carousel, 25 Nov 2026. Working implementations
of all ten directions from that round live in `example/carousel/comps-source.py` — start
from the code, not from the description.

Two cautions from that build. **S12's tear has to be large enough to read as torn** — a
low-amplitude edge looks like a decorative wave, and the sheet below it goes dead unless
it carries real content. **S13 needs genuine bezier paths**: an elliptical border-radius
reads as a rounded rectangle, and a polygon with too few points reads as a lumpy hexagon.

## Sequence (carousels, decks, any multi-page piece)

| # | Move |
|---|---|
| N1 | Bookends: photographic opener and closer, worked interiors between them |
| N2 | Continuous element: one thing holding the same position on every page, so swiping builds it — a horizon band is the clearest case |
| N3 | Numbered corner: a running figure in the same place, same face, every page |
| N4 | Rhythm change at the turn: the interior grid differs from the opener's, and returns at the close |

A set shares at least two things across every page — a recurring motif fragment, the
colour pair, a footer in the same face and place. A direction that only works on the
opener is not a direction; it is a slide.

## Colour

| # | Move |
|---|---|
| C1 | Saturated shape on a desaturated version of its own hue |
| C2 | Flat cut-paper: two or three colours, torn edges, no gradient |
| C3 | Limited inks with visible overprint and slight misregistration |
| C4 | The same asset four times, four ground-and-figure pairs |
| C5 | Palette lifted from a photographed specimen of the farm's |
| C6 | One hue drifting into another across the whole field |
| C7 | Brand colour at architectural scale: pattern panel, plain panel, wordmark |
| C8 | Full chroma reserved for an accent under a tenth of the surface |

Duotone counts as C3 and carries its own trap: reversing type out of a duotone in the
*light* ink of that duotone fails contrast almost every time. Reverse out in paper, or
darken the ground under the type first.

## Surface

| # | Move |
|---|---|
| T1 | Grain over everything, 6-12%, never zero |
| T2 | Leaf shadow multiplied over a flat panel |
| T3 | Woven stripe as a band or an edge |
| T4 | Dense weave in a small area, never behind copy |
| T5 | Out-of-focus colour field behind a cut-out |

## Type

| # | Move |
|---|---|
| Y1 | Display serif doing the talking, sans doing the explaining |
| Y2 | Typewriter for anything that is evidence: dates, coordinates, weights |
| Y3 | Hand-lettering, digital-graphic quadrant only |
| Y4 | Kannada and English as equals on their own lines, never mixed in one line |
| Y5 | One figure set enormous, the rest at caption size |

Y2's evidence has to be real evidence. Typewriter coordinates and altitudes make a piece
look credible, which is exactly why inventing them is worse here than anywhere else —
a drafted "lat 12.72N" was caught and removed from the carousel's notebook direction.

**Open gap.** Caveat is in the type roster as the hand face and has **no file in the
pack**, so Y3 currently falls back to Gaegu. Close it or retire Caveat from the roster.

## What the boards do not license

- No pastiche of a named piece on any board.
- No third-party logo, wordmark or brand colour from the boards.
- No photograph from the boards in an output. The farm's own photographs only.
- The three colours on the texture board (Dusty Blue, Muted Olive, Burnt Sienna) are
  studio reference for how colour behaves. They never enter a brand asset, `brand.json`
  or the brand hub.

A reference the person sends mid-job is read the same way. The land carousel's reference
was a published scrapbook template: the studio took grid ground, rotation, organic blobs
and bookend structure, and reused none of its artwork, lettering or shapes.
