# Varanashi brand pack for asset-studio (v2, 4 Nov 2026)
- `brand.json`: anchors and the extended keys (blue / orange / lichen + complements + tone-on-tone partners), roles, type roles (Fraunces playful + quiet, Pantry stamp, Caveat hand, Hind Mysuru body EN+KN, Kedage Kannada display), formats incl. print A3/A5, copy mechanics incl. AI labels.
- `motifs.py`: lockup (seedling + Fraunces, optional approved Kannada in Kedage), buti repeat, kinar border, rays, rings, rain, scallop stamp edge, roundel, hand arrow/circle/underline, grain, fibre.
- `facts.json`: claims ledger. `grade.py`: archive photo grade. `assets/`: fonts, seedling paths, old lockup SVGs.
New colours (indigo, monsoon, marigold, sprout, areca, rose) are proposals pending Juhi.
