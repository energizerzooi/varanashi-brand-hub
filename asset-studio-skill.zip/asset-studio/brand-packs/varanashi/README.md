# Varanashi brand pack for asset-studio (v4, 24 Nov 2026)

Type system rebuilt 24 Nov 2026. Fraunces, Pantry Label, Hind Mysuru, Kedage,
Glacial Indifference and Big Shoulders Stencil are retired.

- `brand.json` — colour anchors and keys, **the type layer** (roles, measured cap and x
  heights, script pairing ratios, glyph fallbacks, rules), **a licence ledger per face**,
  the logo geometry, formats incl. print A3/A5, copy mechanics.
- `motifs.py` — `lockup()` now serves the **approved outlined artwork** from
  `assets/lockups/`; buti repeat, kinar border, rays, rings, rain, scallop stamp edge,
  roundel, hand arrow/circle/underline, grain, fibre.
- `motifs_v2.py`, `motifs_v3.py` — cut-paper, painted and Hub-motif kits.
- `facts.json` — claims ledger.
- `assets/` — fonts, `varanashi-mark.svg`, `seedling_paths.json`, `lockups/`, `textures/`.

## The type system
ST Nazm (display) + Quicksand (English text) carry the brand. Sentient is the quiet
display voice and the only italic. Noto Sans / Noto Serif Kannada carry Kannada.
Everything else is a guest, one per piece. Full table in `SKILL.md` §7.

## The logotype
Outlined artwork: **ST Nazm wght 800, stylistic set 1, bespoke kerning**, baked from
`scripts/build_lockup.py`. Never set it from live type and never re-kern it. `ss01` is
reserved for the logotype, which is what keeps the mark distinct from a title in the
same face. Below 36px mark height use the mark alone.

Approved Kannada line: **ವಾರಣಾಶಿ ಸಾವಯವ ತೋಟ**, embedded as an 11KB subset of Noto Serif
Kannada inside the SVG, so the lockups need no installed font. The Kannada is live text,
not outlined — HarfBuzz was unavailable; outline it in Illustrator or Figma if a print
vendor insists.

Three fills per lockup: default ink `#2C3D52`, `-paper.svg`, and `-current.svg` which
inherits `color`. **`-current.svg` only works inlined** — through `<img>` it renders black.

## Three traps worth knowing
1. **Always state font-weight.** Sentient defaults to 700, ST Nazm to 250, Quicksand to 300.
2. **CSS `font-weight` caps at 1000.** Above that use `font-variation-settings:'wght' N`;
   a plain `font-weight:1200` is dropped silently. `lint.js` now catches this.
3. **Size by cap height, not font-size.** Zyntra Doodle needs ×1.643 against Quicksand.

## Unresolved
- **Elite Accents** and **Zyntra Doodle** carry no licence text. Not for public work until
  their EULAs are obtained.
- **Lucidity Expand** is unlicensed ($20/style, Aiyari).
- **Caveat** has no file in the pack.
- **ST Nazm** has no copyright, designer or licence in the file. Cleared by the family;
  provenance undocumented.
- **Sentient** requires crediting ITF in design or production credits.
