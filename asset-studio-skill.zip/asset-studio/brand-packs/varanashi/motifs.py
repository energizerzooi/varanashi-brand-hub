"""Varanashi motif, pattern and texture kit for asset-studio.
Every function returns an SVG or HTML string sized in px. Colours are CSS values (use var(--token)).
The seedling is only ever arranged, never redrawn (brand skill §6): paths come from seedling_paths.json."""
import json, math, random
from pathlib import Path
HERE = Path(__file__).parent
SEED = json.load(open(HERE / "assets" / "seedling_paths.json"))  # viewBox 0 0 907 1559
SEED_W, SEED_H = 907, 1559

def seedling(h, colour, extra=""):
    w = h * SEED_W / SEED_H
    return (f'<svg viewBox="0 0 {SEED_W} {SEED_H}" width="{w:.1f}" height="{h}" style="display:block;{extra}" aria-hidden="true">'
            f'<g fill="{colour}">' + "".join(f'<path d="{d}"/>' for d in SEED) + "</g></svg>")

def lockup(h, colour, kannada=None, gap=None):
    """Logomark: the seedling + VARANASHI set in Fraunces (and an approved Kannada line in Kedage, if supplied).
    h = height of the seedling. Never type new Kannada: pass only approved strings."""
    gap = gap or h * 0.16
    kn = (f'<div style="font-family:Kedage;font-size:{h*0.2:.1f}px;line-height:1;margin-top:{h*0.08:.1f}px">{kannada}</div>' if kannada else "")
    return (f'<div style="display:flex;align-items:flex-end;gap:{gap:.1f}px;color:{colour}">{seedling(h, "currentColor")}'
            f'<div style="padding-bottom:{h*0.02:.1f}px"><div style="font-family:Fraunces;font-weight:500;font-variation-settings:\'opsz\' 144,\'SOFT\' 0,\'WONK\' 0;'
            f'font-size:{h*0.52:.1f}px;line-height:.8;letter-spacing:-.01em">Varanashi</div>{kn}</div></div>')

# ---------------- patterns (tone-on-tone by default; luxury lives in low contrast) ----------------
def pat_buti(w, h, ground, ink, size=56, step=None, rot=True, rough=True, opacity=1, uid="buti"):
    """Block-print buti: the seedling in a half-drop repeat, hand-stamped unevenness (rough ink + jitter)."""
    step = step or size * 2.2
    rnd = random.Random(7); sw = size * SEED_W / SEED_H; cells = []
    r = 0
    y = -step
    while y < h + step:
        x = -step + (step / 2 if r % 2 else 0)
        while x < w + step:
            jx, jy, ja = rnd.uniform(-2, 2), rnd.uniform(-2, 2), (rnd.uniform(-5, 5) + (180 if rot and r % 2 else 0))
            op = rnd.uniform(.72, 1)
            cells.append(f'<g transform="translate({x+jx:.1f},{y+jy:.1f}) rotate({ja:.1f} {sw/2:.1f} {size/2:.1f}) scale({size/SEED_H:.4f})" opacity="{op:.2f}"><use href="#{uid}-s"/></g>')
            x += step
        y += step * .5; r += 1
    filt = (f'<filter id="{uid}-r"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="3"/>'
            f'<feDisplacementMap in="SourceGraphic" scale="2.2"/></filter>') if rough else ""
    return (f'<svg width="{w}" height="{h}" style="position:absolute;inset:0" aria-hidden="true"><defs>{filt}'
            f'<g id="{uid}-s" fill="{ink}">' + "".join(f'<path d="{d}"/>' for d in SEED) + f'</g></defs>'
            f'<rect width="{w}" height="{h}" fill="{ground}"/><g opacity="{opacity}" {"filter=url(#%s-r)" % uid if rough else ""}>' + "".join(cells) + "</g></svg>")

def pat_rings(w, h, cx, cy, ink, n=14, gap=34, heavy=4, sw=(1.5, 2.8), uid="rings"):
    """Tree rings, slightly irregular; every fourth heavier (approved motif)."""
    rnd = random.Random(11); out = []
    for i in range(1, n + 1):
        r = i * gap; pts = []
        for k in range(73):
            a = k / 72 * 2 * math.pi
            rr = r * (1 + .018 * math.sin(3 * a + i) + .012 * math.sin(7 * a + 2 * i)) + rnd.uniform(-.6, .6)
            pts.append(f"{cx + rr*math.cos(a):.1f},{cy + rr*math.sin(a):.1f}")
        out.append(f'<polygon points="{" ".join(pts)}" fill="none" stroke="{ink}" stroke-width="{sw[1] if i % heavy == 0 else sw[0]}" stroke-linejoin="round"/>')
    return f'<svg width="{w}" height="{h}" style="position:absolute;inset:0" aria-hidden="true">{"".join(out)}</svg>'

def pat_rays(cx, cy, a, b, n=36):
    """Sunburst: tone-on-tone rays from a point (CSS). a, b = two close tones."""
    s = 360 / n
    return f"repeating-conic-gradient(from 0deg at {cx} {cy}, {a} 0deg {s/2}deg, {b} {s/2}deg {s}deg)"

def pat_rain(w, h, ink, step=28, length=14, angle=-12, sw=2.2, uid="rain"):
    """Monsoon dashes: short slanted strokes in a staggered grid."""
    rnd = random.Random(5); out = []
    for j, y in enumerate(range(-step, h + step, step)):
        for x in range(-step, w + step, step):
            xx = x + (step / 2 if j % 2 else 0) + rnd.uniform(-2, 2)
            dx = length * math.sin(math.radians(angle)); dy = length * math.cos(math.radians(angle))
            out.append(f'<line x1="{xx:.1f}" y1="{y:.1f}" x2="{xx+dx:.1f}" y2="{y+dy:.1f}"/>')
    return f'<svg width="{w}" height="{h}" style="position:absolute;inset:0" aria-hidden="true"><g stroke="{ink}" stroke-width="{sw}" stroke-linecap="round">{"".join(out)}</g></svg>'

def pat_border(w, h, ground, ink, band=88, size=40, uid="border"):
    """Block-print border (a textile 'kinar'): a buti row inside two rules, all four sides."""
    sw = size * SEED_W / SEED_H; out = []
    def row(x0, y0, length, horiz):
        n = int(length // (size * 1.2)); gapl = length / n
        for k in range(n):
            x = x0 + (k + .5) * gapl if horiz else x0; y = y0 if horiz else y0 + (k + .5) * gapl
            rot = 0 if horiz else 90
            out.append(f'<g transform="translate({x:.1f},{y:.1f}) rotate({rot + (180 if k % 2 else 0)}) translate({-sw/2:.1f},{-size/2:.1f}) scale({size/SEED_H:.4f})"><use href="#{uid}-s"/></g>')
    m = band / 2
    row(band, m, w - 2 * band, True); row(band, h - m, w - 2 * band, True)
    row(m, band, h - 2 * band, False); row(w - m, band, h - 2 * band, False)
    rules = "".join(f'<rect x="{o}" y="{o}" width="{w-2*o}" height="{h-2*o}" fill="none" stroke="{ink}" stroke-width="{t}"/>' for o, t in [(10, 3), (band - 10, 1.5)])
    dots = "".join(f'<circle cx="{x}" cy="{y}" r="{size*.28:.1f}" fill="{ink}"/>' for x in (m, w - m) for y in (m, h - m))
    return (f'<svg width="{w}" height="{h}" style="position:absolute;inset:0" aria-hidden="true"><defs><filter id="{uid}-r"><feTurbulence type="fractalNoise" baseFrequency=".8" numOctaves="2" seed="9"/><feDisplacementMap in="SourceGraphic" scale="2"/></filter>'
            f'<g id="{uid}-s" fill="{ink}">' + "".join(f'<path d="{d}"/>' for d in SEED) + f'</g></defs><g filter="url(#{uid}-r)">{rules}{dots}{"".join(out)}</g></svg>')

# ---------------- shapes ----------------
def scallop_path(w, h, r=14):
    """Postage-stamp / scalloped edge as an SVG path for clip-path: path('...')."""
    def edge(x0, y0, x1, y1):
        L = math.hypot(x1 - x0, y1 - y0); n = max(2, round(L / (2 * r))); seg = []
        for k in range(n):
            ax = x0 + (x1 - x0) * (k + 1) / n; ay = y0 + (y1 - y0) * (k + 1) / n
            seg.append(f"A {L/n/2:.2f} {L/n/2:.2f} 0 0 0 {ax:.2f} {ay:.2f}")  # sweep 0: bites into the edge
        return " ".join(seg)
    return f"M 0 0 {edge(0,0,w,0)} {edge(w,0,w,h)} {edge(w,h,0,h)} {edge(0,h,0,0)} Z"

def roundel(d, text, colour, font="Pantry Label", size=30, spacing=".12em", fill=None, inner=None, uid="rnd"):
    """Circular text badge. text should end with ' · ' so it loops cleanly."""
    r = d / 2 - size * .9
    bg = f'<circle cx="{d/2}" cy="{d/2}" r="{d/2}" fill="{fill}"/>' if fill else ""
    return (f'<svg width="{d}" height="{d}" viewBox="0 0 {d} {d}" aria-hidden="true">{bg}<defs><path id="{uid}" d="M {d/2},{d/2} m -{r},0 a {r},{r} 0 1,1 {2*r},0 a {r},{r} 0 1,1 -{2*r},0"/></defs>'
            f'<text font-family="{font}" font-size="{size}" letter-spacing="{spacing}" fill="{colour}"><textPath href="#{uid}" textLength="{2*math.pi*r*.985:.1f}" lengthAdjust="spacing">{text}</textPath></text>{inner or ""}</svg>')

def hand_arrow(w, h, pts, colour, sw=4, head=18, uid="arr"):
    """A hand-drawn arrow through pts [(x,y),...] (local coords), with a wobble filter and an open head."""
    d = f"M {pts[0][0]} {pts[0][1]} " + " ".join(f"Q {pts[i][0]} {pts[i][1]} {(pts[i][0]+pts[i+1][0])/2:.1f} {(pts[i][1]+pts[i+1][1])/2:.1f}" for i in range(1, len(pts) - 1)) + f" T {pts[-1][0]} {pts[-1][1]}"
    (x1, y1), (x2, y2) = pts[-2], pts[-1]; a = math.atan2(y2 - y1, x2 - x1)
    hx = [x2 - head * math.cos(a - .5), y2 - head * math.sin(a - .5)]; hy = [x2 - head * math.cos(a + .5), y2 - head * math.sin(a + .5)]
    return (f'<svg width="{w}" height="{h}" style="overflow:visible" aria-hidden="true"><defs><filter id="{uid}"><feTurbulence type="fractalNoise" baseFrequency=".05" numOctaves="2" seed="4"/><feDisplacementMap in="SourceGraphic" scale="3"/></filter></defs>'
            f'<g fill="none" stroke="{colour}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" filter="url(#{uid})"><path d="{d}"/>'
            f'<path d="M {hx[0]:.1f} {hx[1]:.1f} L {x2} {y2} L {hy[0]:.1f} {hy[1]:.1f}"/></g></svg>')

def hand_circle(w, h, colour, sw=4, uid="hc"):
    """A loose hand-drawn ellipse that overshoots its start, for circling a word or detail."""
    cx, cy, rx, ry = w / 2, h / 2, w / 2 - sw, h / 2 - sw; pts = []
    for k in range(0, 400, 8):
        a = math.radians(k - 20); g = 1 + .04 * math.sin(a * 2.3)
        pts.append(f"{cx + rx*g*math.cos(a):.1f},{cy + ry*g*math.sin(a)*(1 - k/4000):.1f}")
    return (f'<svg width="{w}" height="{h}" style="overflow:visible" aria-hidden="true"><defs><filter id="{uid}"><feTurbulence type="fractalNoise" baseFrequency=".04" seed="2"/><feDisplacementMap in="SourceGraphic" scale="4"/></filter></defs>'
            f'<polyline points="{" ".join(pts)}" fill="none" stroke="{colour}" stroke-width="{sw}" stroke-linecap="round" filter="url(#{uid})"/></svg>')

def hand_underline(w, colour, sw=5, uid="hu"):
    return (f'<svg width="{w}" height="24" style="overflow:visible" aria-hidden="true"><path d="M 4 14 C {w*.3:.0f} 6, {w*.6:.0f} 20, {w-4} 9" fill="none" stroke="{colour}" stroke-width="{sw}" stroke-linecap="round"/></svg>')

# ---------------- textures ----------------
def grain(w, h, opacity=.16, freq=.85, blend="multiply", uid="grain"):
    """Risograph / paper grain over the whole canvas."""
    return (f'<svg width="{w}" height="{h}" style="position:absolute;inset:0;mix-blend-mode:{blend};opacity:{opacity};pointer-events:none" aria-hidden="true">'
            f'<filter id="{uid}"><feTurbulence type="fractalNoise" baseFrequency="{freq}" numOctaves="3" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/></filter>'
            f'<rect width="100%" height="100%" filter="url(#{uid})"/></svg>')

def fibre(w, h, opacity=.10, uid="fibre"):
    """Long paper fibres, for print-feel grounds."""
    return (f'<svg width="{w}" height="{h}" style="position:absolute;inset:0;mix-blend-mode:multiply;opacity:{opacity};pointer-events:none" aria-hidden="true">'
            f'<filter id="{uid}"><feTurbulence type="fractalNoise" baseFrequency=".012 .22" numOctaves="2" seed="8"/><feColorMatrix type="saturate" values="0"/></filter>'
            f'<rect width="100%" height="100%" filter="url(#{uid})"/></svg>')
