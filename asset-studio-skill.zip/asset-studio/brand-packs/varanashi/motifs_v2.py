"""Asset Studio v2 kit · from the VOF Design 'Output matrix' board (Nov 2026).
Cut paper, painted rings, ticking and wavy stripes, grainy gradients, dappled light, linocut photos,
photo punch-outs, sticker ovals. All SVG/CSS, rendered in Chromium. Sizes in px."""
import math, random

def _rough(uid, freq=.025, scale=12, seed=3):
    return (f'<filter id="{uid}" x="-10%" y="-10%" width="120%" height="120%">'
            f'<feTurbulence type="fractalNoise" baseFrequency="{freq}" numOctaves="3" seed="{seed}" result="n"/>'
            f'<feDisplacementMap in="SourceGraphic" in2="n" scale="{scale}" xChannelSelector="R" yChannelSelector="G" result="d"/>'
            f'<feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="{seed+5}" result="g"/>'
            f'<feColorMatrix in="g" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -.9 .62" result="ga"/>'
            f'<feComposite in="ga" in2="d" operator="in" result="gi"/><feMerge><feMergeNode in="d"/><feMergeNode in="gi"/></feMerge></filter>')

def cut(w, h, inner, uid="cut", freq=.025, scale=12, seed=3, extra=""):
    """Wrap any SVG shapes so they read as cut or torn paper: wobbly edge + paper fibre in the fill."""
    return f'<svg width="{w}" height="{h}" style="overflow:visible;{extra}" aria-hidden="true"><defs>{_rough(uid, freq, scale, seed)}</defs><g filter="url(#{uid})">{inner}</g></svg>'

def sun(cx, cy, r, fill, wob=.06, seed=2):
    rnd = random.Random(seed); n = 18; pts = []
    for i in range(n):
        a = i / n * 2 * math.pi; rr = r * (1 + rnd.uniform(-wob, wob)); pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d = f"M {(pts[0][0]+pts[-1][0])/2:.1f} {(pts[0][1]+pts[-1][1])/2:.1f} " + "".join(f"Q {p[0]:.1f} {p[1]:.1f} {(p[0]+q[0])/2:.1f} {(p[1]+q[1])/2:.1f} " for p, q in zip(pts, pts[1:] + pts[:1]))
    return f'<path d="{d}Z" fill="{fill}"/>'

def wave_band(w, y, amp, thick, fill, n=2.2, phase=0):
    top = [(x, y + amp * math.sin(x / w * n * 2 * math.pi + phase)) for x in range(-20, w + 21, 20)]
    bot = [(x, yy + thick) for x, yy in reversed(top)]
    return f'<path d="M {" L ".join(f"{x:.0f} {yy:.1f}" for x, yy in top + bot)} Z" fill="{fill}"/>'

def star(cx, cy, r, fill, arms=5, inner=.42, seed=4, rot=-90):
    rnd = random.Random(seed); pts = []
    for i in range(arms * 2):
        a = math.radians(rot) + i / (arms * 2) * 2 * math.pi
        rr = (r if i % 2 == 0 else r * inner) * (1 + rnd.uniform(-.12, .12)); pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d = f"M {(pts[0][0]+pts[-1][0])/2:.1f} {(pts[0][1]+pts[-1][1])/2:.1f} " + "".join(f"Q {p[0]:.1f} {p[1]:.1f} {(p[0]+q[0])/2:.1f} {(p[1]+q[1])/2:.1f} " for p, q in zip(pts, pts[1:] + pts[:1]))
    return f'<path d="{d}Z" fill="{fill}"/>'

def painted_rings(w, h, cx, cy, rings, uid="pr"):
    """Concentric hand-painted rings: rings = [(radius, width, colour), ...]. Tree rings, painted."""
    out = "".join(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{c}" stroke-width="{sw}"/>' for r, sw, c in rings)
    filt = (f'<filter id="{uid}" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency=".018" numOctaves="3" seed="6" result="n"/>'
            f'<feDisplacementMap in="SourceGraphic" in2="n" scale="26" result="d"/><feTurbulence type="fractalNoise" baseFrequency="0.9 .04" numOctaves="2" seed="2" result="b"/>'
            f'<feColorMatrix in="b" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.1 1.3" result="ba"/><feComposite in="d" in2="ba" operator="in"/></filter>')
    return f'<svg width="{w}" height="{h}" style="position:absolute;inset:0" aria-hidden="true"><defs>{filt}</defs><g filter="url(#{uid})">{out}</g></svg>'

def ticking(a, b, c=None, base=26):
    """Mattress-ticking stripe as a CSS background (a = ground, b = main stripe, c = accent stripe)."""
    c = c or b
    return (f"repeating-linear-gradient(90deg, {a} 0 {base}px, {b} {base}px {base+5}px, {a} {base+5}px {base+10}px, {b} {base+10}px {base+15}px,"
            f" {a} {base+15}px {base*2+15}px, {c} {base*2+15}px {base*2+21}px, {a} {base*2+21}px {base*3+21}px)")

def wavy_stripes(w, h, colours, band=96, amp=34, uid="ws"):
    """Vertical wavy bands like the rug on the board; colours cycle."""
    out = []; n = int(w / band) + 3
    for i in range(n):
        x0 = (i - 1) * band; ph = (i % 2) * math.pi
        left = [(x0 + amp * math.sin(y / 260 * 2 * math.pi + ph), y) for y in range(-20, h + 41, 20)]
        right = [(x + band, y) for x, y in reversed(left)]
        out.append(f'<path d="M {" L ".join(f"{x:.1f} {y}" for x, y in left + right)} Z" fill="{colours[i % len(colours)]}"/>')
    return (f'<svg width="{w}" height="{h}" style="position:absolute;inset:0" aria-hidden="true"><defs><filter id="{uid}"><feTurbulence type="fractalNoise" baseFrequency=".02" seed="5"/><feDisplacementMap in="SourceGraphic" scale="6"/></filter></defs>'
            f'<g filter="url(#{uid})">{"".join(out)}</g></svg>')

def grainy_gradient(stops):
    """Blurred multi-blob gradient (CSS). stops = [(x%, y%, colour, size%), ...] over a base colour (first stop)."""
    base = stops[0][2]
    layers = ", ".join(f"radial-gradient(circle at {x}% {y}%, {c} 0, transparent {s}%)" for x, y, c, s in stops[1:])
    return f"{layers}, {base}"

def dappled(w, h, ground, lights, n=22, seed=8, blur=34):
    """Dappled leaf-light: soft blurred light patches on a ground."""
    rnd = random.Random(seed)
    blobs = "".join(f'<ellipse cx="{rnd.uniform(0,w):.0f}" cy="{rnd.uniform(0,h):.0f}" rx="{rnd.uniform(40,150):.0f}" ry="{rnd.uniform(30,110):.0f}" fill="{rnd.choice(lights)}" opacity="{rnd.uniform(.5,.95):.2f}" transform="rotate({rnd.uniform(-40,40):.0f})"/>' for _ in range(n))
    return f'<svg width="{w}" height="{h}" style="position:absolute;inset:0" aria-hidden="true"><defs><filter id="dp"><feGaussianBlur stdDeviation="{blur}"/></filter></defs><rect width="{w}" height="{h}" fill="{ground}"/><g filter="url(#dp)">{blobs}</g></svg>'

def lino_photo(src, x, y, w, h, ink, paper, cut=.48, pos="xMidYMid slice", uid="lino"):
    """Photo as a one-ink linocut: luminance → hard threshold → ink on paper."""
    lo = ink.lstrip('#'); pa = paper.lstrip('#')
    r1, g1, b1 = [int(lo[i:i+2], 16) / 255 for i in (0, 2, 4)]; r2, g2, b2 = [int(pa[i:i+2], 16) / 255 for i in (0, 2, 4)]
    return (
            f'<svg class="a" style="left:{x}px;top:{y}px" width="{w}" height="{h}" aria-hidden="true"><defs><filter id="{uid}" color-interpolation-filters="sRGB">'
            f'<feColorMatrix type="matrix" values=".3 .59 .11 0 0 .3 .59 .11 0 0 .3 .59 .11 0 0 0 0 0 1 0" result="g"/>'
            f'<feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="2" result="nz"/>'
            f'<feComposite in="g" in2="nz" operator="arithmetic" k2="1.25" k3=".12" k4="{-.18 + (.5 - cut):.2f}" result="gn"/>'
            f'<feComponentTransfer in="gn" result="t"><feFuncR type="discrete" tableValues="0 1"/><feFuncG type="discrete" tableValues="0 1"/><feFuncB type="discrete" tableValues="0 1"/></feComponentTransfer>'
            f'<feColorMatrix in="t" type="matrix" values="{r2-r1:.3f} 0 0 0 {r1:.3f}  0 {g2-g1:.3f} 0 0 {g1:.3f}  0 0 {b2-b1:.3f} 0 {b1:.3f}  0 0 0 1 0"/></filter></defs>'
            f'<image href="{src}" width="{w}" height="{h}" preserveAspectRatio="{pos}" filter="url(#{uid})"/></svg>')

def punchout(w, h, x, y, bw, bh, fill, holes, uid="po"):
    """A colour field with circular holes that show the photo underneath. holes = [(cx, cy, r), ...] relative to the field."""
    circles = "".join(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="black"/>' for cx, cy, r in holes)
    return (f'<svg class="a" style="left:{x}px;top:{y}px" width="{bw}" height="{bh}" aria-hidden="true"><defs><mask id="{uid}"><rect width="{bw}" height="{bh}" fill="white"/>{circles}</mask></defs>'
            f'<rect width="{bw}" height="{bh}" fill="{fill}" mask="url(#{uid})"/></svg>')

def sticker_oval(w, h, fill, html, rot=-6, border=None):
    b = f"border:3px solid {border};" if border else ""
    return f'<div style="width:{w}px;height:{h}px;border-radius:50%;background:{fill};{b}transform:rotate({rot}deg);display:flex;align-items:center;justify-content:center;text-align:center">{html}</div>'


# ---------------- v2.1 · texture overlays and focal-safe photos ----------------
import json as _json, os as _os
from pathlib import Path as _P
_HERE = _P(__file__).parent; TEX = _HERE / "assets" / "textures"
_FOC = _json.load(open(_HERE / "photos_focal.json")) if (_HERE / "photos_focal.json").exists() else {}

_TEXN = [0]
def tex(name, colour, opacity=.2, blend="multiply", size="cover", rot=0, inset="0", extra="", w=1600, h=1600):
    """A transparent texture laid over a surface, in any colour: wood_plank, wood_knots, paint_horizontal,
    paint_diagonal, paint_scumble, paper_tooth. Light grounds: a darker tone + multiply. Dark grounds: a lighter tone + screen.
    Drawn as an SVG alpha mask (CSS masks from local files are blocked by Chromium)."""
    _TEXN[0] += 1; uid = f"tx{_TEXN[0]}"
    tr = f' transform="rotate({rot} {w/2} {h/2})"' if rot else ""
    return (f'<svg class="a" data-role="ignore" aria-hidden="true" viewBox="0 0 {w} {h}" preserveAspectRatio="xMidYMid slice" '
            f'style="inset:{inset};width:100%;height:100%;pointer-events:none;opacity:{opacity};mix-blend-mode:{blend};{extra}">'
            f'<defs><mask id="{uid}" style="mask-type:alpha"><image href="{TEX}/{name}.png" x="-200" y="-200" width="{w+400}" height="{h+400}" preserveAspectRatio="xMidYMid slice"{tr}/></mask></defs>'
            f'<rect width="{w}" height="{h}" fill="{colour}" mask="url(#{uid})"/></svg>')

def surface(colour, *layers):
    """A ground colour plus texture layers: surface('#9BB6C4', ('paint_diagonal', '#7F9BAC', .5), ('paper_tooth', '#000', .12))."""
    return f'<div class="a" data-role="ignore" style="inset:0;background:{colour}"></div>' + "".join(tex(n, c, o, *rest) for n, c, o, *rest in layers)

def cut_tex(w, h, inner, uid="ct", texture="paint_scumble", tone="#ffffff", op=.35, freq=.025, scale=12, seed=3, extra=""):
    """cut() plus a paint texture living only inside the shapes (gouache on cut paper)."""
    return (f'<svg width="{w}" height="{h}" style="overflow:visible;{extra}" aria-hidden="true"><defs>{_rough(uid, freq, scale, seed)}'
            f'<mask id="{uid}m"><g filter="url(#{uid})" fill="white">{inner.replace("fill=", "data-f=")}</g></mask>'
            f'<mask id="{uid}t" style="mask-type:alpha"><image href="{TEX}/{texture}.png" width="{w}" height="{h}" preserveAspectRatio="xMidYMid slice"/></mask></defs>'
            f'<g filter="url(#{uid})">{inner}</g><g mask="url(#{uid}m)"><rect width="{w}" height="{h}" fill="{tone}" opacity="{op}" mask="url(#{uid}t)"/></g></svg>')

def focal_rect(name, x, y, w, h, pos=(50, 50), zoom=1.0):
    """Where a photo's focal box lands on the canvas when it is placed with background-size:cover (× zoom) at pos (%)."""
    f = _FOC.get(name); 
    if not f: return None
    iw, ih = f["size"]; s = max(w / iw, h / ih) * zoom; dw, dh = iw * s, ih * s
    ox, oy = x + (w - dw) * pos[0] / 100, y + (h - dh) * pos[1] / 100
    b = f["box"]; return [round(ox + b[0] * dw), round(oy + b[1] * dh), round(ox + b[2] * dw), round(oy + b[3] * dh)]

def photo(src_dir, name, x, y, w, h, pos=(50, 50), zoom=1.0, extra="", texture_only=False):
    """A photo div that carries its focal box (data-focal) so lint can keep shapes off the subject.
    texture_only=True for a photo used as ambience behind other layers (no focal protection)."""
    fr = None if texture_only else focal_rect(name, x, y, w, h, pos, zoom)
    df = f' data-focal="{",".join(map(str, fr))}"' if fr else ""
    size = "cover" if zoom == 1 else f"{zoom * 100:.0f}%"
    if zoom != 1:
        f = _FOC.get(name, {"size": [w, h]}); iw, ih = f["size"]; s = max(w / iw, h / ih) * zoom; size = f"{iw*s:.0f}px {ih*s:.0f}px"
    return (f'<div class="a ph" data-role="photo"{df} style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;background-image:url({src_dir}/{name}.jpg);'
            f'background-size:{size};background-position:{pos[0]}% {pos[1]}%;background-repeat:no-repeat;{extra}"></div>')
