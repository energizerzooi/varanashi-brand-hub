# The farm's photographs

Every image used in an asset comes from here. No stock, nothing generated, nothing lifted
from a reference board.

## Resolution, and why it is listed

A photograph that arrives through WhatsApp has been recompressed. Measure before
committing it to a full-bleed layout rather than discovering the softness at the end.
The rule of thumb: **full-bleed at 1080 needs the short edge at 1080 or better; a collaged
fragment needs about a third of that.** A large print needs roughly 3600px across.

| File | Pixels | Full-bleed 1080 | Notes |
|---|---|---|---|
| `photo-spring-swim.jpg` | 1280×720 | 1.5× upscale — soft | the spring, someone mid-stroke. The farm's strongest single image |
| `photo-paddy-visitors.jpg` | 1280×960 | 1.13× — passable | **about twenty identifiable children.** Confirm consent before any public use |
| `photo-cacao-hands.jpg` | 960×1280 | 1.13× — passable | wet cacao beans, cupped hands |
| `photo-calf.jpg` | 960×1280 | 1.13× — passable | calf, tongue out. The only genuinely funny picture in the library |
| `photo-cottage.jpg` | 1280×853 | 1.27× — marginal | laterite cottage, lit, in forest |
| `photo-beans-harvest.jpg` | 853×1280 | 1.27× — marginal | long beans, kitchen garden. Identifiable adult |
| `photo-seedling-coir.jpg` | 853×1280 | 1.27× — marginal | seedling in coir mulch |
| `photo-cacao-sprout.jpg` | 499×750 | no | fragment only, ≤500px placed |
| `photo-amaryllis.jpg` | 1200×1600 | yes | |
| `photo-bamboo-path.jpg` | 1200×1600 | yes | |
| `photo-biogas-sign.jpg` | 1204×1599 | yes | |
| `photo-bracket-fungus.jpg` | 1204×1599 | yes | not a thing that grows *for* us — don't file it under produce |
| `photo-morning-glory.jpg` | 1200×1600 | yes | |
| `photo-roots.jpg` | 1200×1600 | yes | |
| `photo-signpost.jpg` | 1200×1600 | yes | |
| `photo-spring-pool.jpg` | 1200×1600 | yes | the pool without a swimmer |
| `photo-woven-fronds.jpg` | 1204×1599 | yes | |
| `photo-forest.jpg` | 1280×960 | 1.13× — passable | |
| `photo-sun-halo.jpg` | 899×1599 | 1.2× — marginal | |
| `photo-aerial-garden.jpg` | 520×360 | no | fragment only |

`poster-*.jpg` are finished pieces, not source material. Don't crop them into new work.

## People in the frame

Several photographs show identifiable people, and one shows a large group of children.
These are the farm's own pictures of its own visitors, so the decision is the farm's — but
**raise it rather than assume it** whenever such a photograph is headed somewhere public.
