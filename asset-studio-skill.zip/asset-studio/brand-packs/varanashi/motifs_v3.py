"""Asset Studio v3 kit additions (5 Nov 2026): Brand Hub motifs with texture, and photo treatments.
dry_rings · stamp (lino icon, printed stroke) · window (ornament photo window) · png_shape (petals as delight)
clip (binder-clipped print) · sparkle · doodle_star (hand-drawn accents over photos)."""
import math
from motifs_v2 import _rough, TEX

def dry_rings(W, H, cx, cy, r0, step, n, colour, uid, heavy=4):
    """Tree rings in dry brush: uneven ink, every `heavy`-th ring heavier. Off an empty corner or around a round photo."""
    rings = "".join(f'<circle cx="{cx}" cy="{cy}" r="{r0 + i*step + (i*7 % 5)}" fill="none" stroke="{colour}" stroke-width="{16 if i % heavy == heavy-1 else 8}"/>' for i in range(n))
    filt = (f'<filter id="{uid}" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency=".012" numOctaves="2" seed="9" result="n"/>'
            f'<feDisplacementMap in="SourceGraphic" in2="n" scale="18" result="d"/>'
            f'<feTurbulence type="fractalNoise" baseFrequency="1.1 .035" numOctaves="2" seed="3" result="b"/>'
            f'<feColorMatrix in="b" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.6 1.45" result="ba"/>'
            f'<feComposite in="d" in2="ba" operator="in"/></filter>')
    return f'<svg class="a" data-role="shape" style="left:0;top:0" width="{W}" height="{H}"><defs>{filt}</defs><g filter="url(#{uid})">{rings}</g></svg>'
def stamp(d, x, y, s, ink, second, uid, fill=.6):
    """A drawn icon (24-unit path d) as a lino stamp: speckled second-colour disc offset behind, and a printed stroke
    (uneven weight, edge bleed, small gaps, swelling ends). The icon fills `fill` (~.55-.6) of the disc."""
    speck = (f'<filter id="{uid}" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency=".05" numOctaves="2" seed="4" result="w"/>'
             f'<feDisplacementMap in="SourceGraphic" in2="w" scale="1.1" result="d"/>'
             f'<feTurbulence type="fractalNoise" baseFrequency="2.2" numOctaves="1" seed="8" result="s"/>'
             f'<feColorMatrix in="s" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -3 2.3" result="sa"/>'
             f'<feComposite in="d" in2="sa" operator="in"/></filter>')
    disc = f'<circle cx="12" cy="12" r="11.2" fill="{second}"/>'
    return (f'<svg class="a" data-role="shape" style="left:{x}px;top:{y}px;overflow:visible" width="{s}" height="{s}" viewBox="0 0 24 24"><defs>{speck}</defs>'
            f'<g filter="url(#{uid})" transform="translate(.5 .7)">{disc}</g>'
            f'<filter id="{uid}s" x="-10%" y="-10%" width="120%" height="120%">'
            f'<feTurbulence type="fractalNoise" baseFrequency=".35" numOctaves="2" seed="11" result="w"/>'
            f'<feDisplacementMap in="SourceGraphic" in2="w" scale=".55" result="d"/>'
            f'<feGaussianBlur in="d" stdDeviation=".22" result="bl"/>'
            f'<feComponentTransfer in="bl" result="bleed"><feFuncA type="table" tableValues="0 0 .55 1 1"/></feComponentTransfer>'
            f'<feTurbulence type="fractalNoise" baseFrequency="1.3" numOctaves="2" seed="21" result="g"/>'
            f'<feColorMatrix in="g" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -2.4 2.05" result="ga"/>'
            f'<feComposite in="bleed" in2="ga" operator="in"/></filter>'
            f'<g filter="url(#{uid}s)"><g transform="translate(12 12) scale({fill}) translate(-12 -12)"><path d="{d}" fill="none" stroke="{ink}" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>'
            f'<path d="{d}" fill="none" stroke="{ink}" stroke-width="2.6" stroke-linecap="round" stroke-dasharray=".01 30" opacity=".9"/></g></g></svg>')
def png_shape(f, x, y, w, h, colour, uid, rot=0, texture="paint_scumble", tone="#FFFFFF", op=.16, scale=10):
    """A Brand Hub PNG (petal, ornament) as a cut-paper shape: recoloured, torn edge, gouache inside. Petals are delight only: no text inside."""
    return (f'<svg class="a" data-role="shape" style="left:{x}px;top:{y}px;overflow:visible;transform:rotate({rot}deg)" width="{w}" height="{h}"><defs>{_rough(uid, .03, scale)}'
            f'<mask id="{uid}m" style="mask-type:alpha"><image href="{f}" width="{w}" height="{h}"/></mask>'
            f'<mask id="{uid}t" style="mask-type:alpha"><image href="{TEX}/{texture}.png" width="{w}" height="{h}" preserveAspectRatio="xMidYMid slice"/></mask></defs>'
            f'<g filter="url(#{uid})"><g mask="url(#{uid}m)"><rect width="{w}" height="{h}" fill="{colour}"/><rect width="{w}" height="{h}" fill="{tone}" opacity="{op}" mask="url(#{uid}t)"/></g></g></svg>')

def window(f, photo_src, x, y, s, uid, ox=-200, oy=-40):
    """A Hub ornament as a torn-edged window with a photo showing through it."""
    return (f'<svg class="a" data-role="photo" style="left:{x}px;top:{y}px" width="{s}" height="{s}"><defs>{_rough(uid + "f", .025, 10)}'
            f'<mask id="{uid}" style="mask-type:alpha"><g filter="url(#{uid}f)"><image href="{f}" width="{s}" height="{s}"/></g></mask></defs>'
            f'<image href="{photo_src}" x="{ox}" y="{oy}" width="{s+400}" height="{s+120}" preserveAspectRatio="xMidYMid slice" mask="url(#{uid})"/></svg>')

def clip(x, y, s=1.0):
    """A wire binder clip, drawn."""
    return (f'<svg class="a" style="left:{x}px;top:{y}px;overflow:visible" width="{220*s}" height="{240*s}" viewBox="0 0 220 240"><defs><linearGradient id="mt" x1="0" x2="1"><stop offset="0" stop-color="#8E9196"/><stop offset=".45" stop-color="#F2F3F1"/><stop offset="1" stop-color="#7B7E83"/></linearGradient></defs>'
            f'<g fill="none" stroke="url(#mt)" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" filter="drop-shadow(4px 8px 6px rgba(0,0,0,.35))">'
            f'<path d="M70 150 L70 40 Q70 10 110 10 Q150 10 150 40 L150 150"/><path d="M85 150 L85 50 Q85 30 110 30 Q135 30 135 50 L135 150"/>'
            f'<path d="M20 150 L200 150 L180 232 L40 232 Z" stroke-width="8"/><path d="M45 190 L175 190" stroke-width="4" opacity=".6"/></g></svg>')

def sparkle(x, y, s, colour, rot=0):
    return f'<svg class="a" data-role="shape" style="left:{x}px;top:{y}px;transform:rotate({rot}deg);overflow:visible" width="{s}" height="{s}" viewBox="-50 -50 100 100"><path d="M0 -48 C 6 -10 10 -6 48 0 C 10 6 6 10 0 48 C -6 10 -10 6 -48 0 C -10 -6 -6 -10 0 -48 Z" fill="{colour}"/></svg>'
def doodle_star(x, y, s, colour, rot=0):
    pts = " ".join(f"{(46 if i % 2 == 0 else 20) * math.cos(math.radians(-90 + i * 36)):.1f},{(46 if i % 2 == 0 else 20) * math.sin(math.radians(-90 + i * 36)):.1f}" for i in range(10))
    return f'<svg class="a" data-role="shape" style="left:{x}px;top:{y}px;transform:rotate({rot}deg);overflow:visible" width="{s}" height="{s}" viewBox="-50 -50 100 100"><polygon points="{pts}" fill="none" stroke="{colour}" stroke-width="5" stroke-linejoin="round"/></svg>'

