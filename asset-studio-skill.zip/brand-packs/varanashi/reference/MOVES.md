# The move set

Distilled once from the three direction boards in `boards/`. This replaces per-job
browsing: the studio reads this, not Pinterest or Cosmos, unless the farm asks for a
live round.

**The rule that governs all of it.** A move is a verb, not a picture. "Objects scattered
on one strong ground" is a move. The particular poster on the board that does it is not
yours to rebuild. If a draft could be mistaken for a specific board piece, throw it away
and use the move differently.

Each direction in a round cites one or two moves by name, and says where it sits on the
matrix. Two directions may not cite the same pair.

## Structure

| # | Move | Where it lives |
|---|---|---|
| S1 | One big word, everything else small | print-graphic, digital-graphic |
| S2 | Strict column grid with visible rules | print-informative |
| S3 | Equal tiles, one idea each, repeated | digital-informative |
| S4 | Window: a photograph cropped to a shape, type outside it | any |
| S5 | Field and object: one cut-out thing on an open ground | digital-graphic |
| S6 | Annotated drawing with labelled leaders | print-informative |
| S7 | Stamp or seal as the whole composition | print-graphic |
| S8 | Ledger: ruled rows, figures aligned on a decimal | print-informative |
| S9 | Edge-to-edge pattern with one plain panel cut into it | any |
| S10 | Stacked bands, each a different ground, type crossing them | digital-graphic |

## Colour

| # | Move |
|---|---|
| C1 | Saturated shape on a desaturated version of its own hue |
| C2 | Flat cut-paper: two or three colours, torn edges, no gradient |
| C3 | Limited inks with visible overprint and slight misregistration |
| C4 | The same asset four times, four ground-and-figure pairs |
| C5 | Palette lifted from a photographed specimen of the farm's |
| C6 | One hue drifting into another across the whole field |
| C7 | Brand colour at architectural scale: pattern panel, plain panel, wordmark |
| C8 | Full chroma reserved for an accent under a tenth of the surface |

## Surface

| # | Move |
|---|---|
| T1 | Grain over everything, 6-12%, never zero |
| T2 | Leaf shadow multiplied over a flat panel |
| T3 | Woven stripe as a band or an edge |
| T4 | Dense weave in a small area, never behind copy |
| T5 | Out-of-focus colour field behind a cut-out |

## Type

| # | Move |
|---|---|
| Y1 | Display serif doing the talking, sans doing the explaining |
| Y2 | Typewriter for anything that is evidence: dates, coordinates, weights |
| Y3 | Hand-lettering, digital-graphic quadrant only |
| Y4 | Kannada and English as equals on their own lines, never mixed in one line |
| Y5 | One figure set enormous, the rest at caption size |

## What the boards do not license

- No pastiche of a named piece on any board.
- No third-party logo, wordmark or brand colour from the boards.
- No photograph from the boards in an output. The farm's own photographs only.
- The three colours on the texture board (Dusty Blue, Muted Olive, Burnt Sienna) are
  studio reference for how colour behaves. They never enter a brand asset, `brand.json`
  or the brand hub.
